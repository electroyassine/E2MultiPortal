#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
CacheManager — petit cache JSON generique sur disque.

Sert a memoriser les dernieres listes recues d'un serveur (categories VOD,
categories series, chaines, etc.) afin que l'interface puisse continuer a
afficher des donnees meme si le serveur ne repond pas / renvoie une liste
vide au chargement suivant (probleme rencontre avec certains serveurs
Xtream qui ne repondent correctement qu'a la premiere requete apres le test
de connexion).

Le cache est stocke sur le meme support que les posters (disque externe si
disponible, sinon flash) pour ne pas saturer /etc.
"""
import json, os, time, hashlib

try:
    from . import poster_manager as _PM
    _BASE = os.path.join(os.path.dirname(_PM.DIR_PERM), "cache")
except Exception:
    _BASE = "/etc/enigma2/E2MultiPortal/cache"

try:
    os.makedirs(_BASE, exist_ok=True)
except Exception:
    pass


def _path(key):
    h = hashlib.md5(key.encode("utf-8")).hexdigest()
    return os.path.join(_BASE, h + ".json")


def save(key, data):
    """Sauvegarde data (liste/dict JSON-serialisable) sous la cle key."""
    try:
        with open(_path(key), "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f)
        return True
    except Exception as e:
        print("[Cache] save %s: %s" % (key, e))
        return False


def load(key, max_age=None):
    """Charge les donnees pour key. Retourne None si absent/expire.
    max_age en secondes (None = pas de limite)."""
    try:
        with open(_path(key), "r", encoding="utf-8") as f:
            obj = json.load(f)
        if max_age is not None and (time.time() - obj.get("ts", 0)) > max_age:
            return None
        return obj.get("data")
    except Exception:
        return None


def get_or_fetch(key, fetch_fn, is_valid=None, max_age=None):
    """Appelle fetch_fn() ; si le resultat est considere valide (non vide
    par defaut, ou selon is_valid(result)), le sauvegarde et le retourne.
    Sinon retombe sur le cache (meme expire) si disponible.

    Retourne (data, from_cache: bool)."""
    if is_valid is None:
        is_valid = lambda r: bool(r)

    try:
        result = fetch_fn()
    except Exception as e:
        print("[Cache] fetch %s: %s" % (key, e))
        result = None

    if is_valid(result):
        save(key, result)
        return result, False

    cached = load(key, max_age=max_age)
    if cached is not None and is_valid(cached):
        return cached, True

    return result, False
