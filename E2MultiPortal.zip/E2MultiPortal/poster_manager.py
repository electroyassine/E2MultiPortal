#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
PosterManager — Gestion centralisée des posters
- Stocke les posters sur un disque externe (/media/hdd ou /media/usb) si
  disponible, pour ne pas saturer la flash interne (/etc, /tmp).
- Cherche dans /tmp/e2mp_posters (ancien/cache rapide) et dans le dossier
  permanent détecté (DIR_PERM) ci-dessous.
- Convertit automatiquement JPEG/WEBP en PNG pour Enigma2 (loadPNG ne lit que les PNG)
- Télécharge depuis le serveur (stream_icon, cover...) puis TMDB en fallback
"""
import os, ssl, hashlib, threading, urllib.request, json, re


def _detect_poster_dir():
    """Cherche un emplacement sur disque externe (/media/hdd puis /media/usb*),
    sinon retombe sur le dossier flash /etc/enigma2 (compatibilité)."""
    candidates = ["/media/hdd"]
    try:
        if os.path.isdir("/media"):
            for name in sorted(os.listdir("/media")):
                if name.startswith("usb"):
                    candidates.append(os.path.join("/media", name))
    except Exception:
        pass
    candidates.append("/media/usb")

    for base in candidates:
        try:
            if os.path.isdir(base) and os.access(base, os.W_OK):
                path = os.path.join(base, "E2MultiPortal", "posters")
                os.makedirs(path, exist_ok=True)
                return path
        except Exception:
            continue
    # Fallback : flash interne (ancien comportement)
    path = "/etc/enigma2/E2MultiPortal/posters"
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


DIR_PERM = _detect_poster_dir()
DIR_TMP  = "/tmp/e2mp_posters"
TMDB_KEY = "4f4d38a3a9ab6f0c62a0a7c9b6d3e1a5"
IMG_EXTS = ('.jpg','.jpeg','.png','.webp','.JPG','.PNG','.JPEG')

# ── Nettoyage des titres avant recherche TMDB ───────────────────────────────
# Les listes IPTV prefixent/suffixent souvent les titres avec des tags
# (langue, qualite, annee, pays) : "NF - The Rookie", "|FR| SPORT",
# "FR - Les Quatre Saisons (2025)", "FR - Outlander (2014) (US)" ...
# Ces tags font echouer la recherche TMDB ; on les retire pour la requete.
_TITLE_PIPE_RE   = re.compile(r'^\s*\|[A-Za-z0-9]{1,5}\|\s*')
_TITLE_PREFIX_RE = re.compile(r'^\s*[A-Z]{1,6}\s-\s+')
_TITLE_SUFFIX_RE = re.compile(r'\s*\((?:19|20)\d{2}\)\s*$|\s*\([A-Z]{2,4}\)\s*$')


def clean_title(title):
    """Retire les tags IPTV courants (prefixes |FR|/NF -/SRS -..., suffixes
    (2025)/(US)...) pour ameliorer la recherche TMDB. Retourne le titre
    original si le nettoyage produit une chaine vide."""
    if not title:
        return title
    t = title
    changed = True
    while changed:
        changed = False
        for rx in (_TITLE_PIPE_RE, _TITLE_PREFIX_RE):
            new_t = rx.sub('', t)
            if new_t != t:
                t = new_t
                changed = True
    changed = True
    while changed:
        new_t = _TITLE_SUFFIX_RE.sub('', t)
        changed = (new_t != t)
        t = new_t
    t = t.strip(" -:|")
    return t or title


def init_dirs():
    for d in (DIR_PERM, DIR_TMP):
        try: os.makedirs(d, exist_ok=True)
        except Exception: pass

init_dirs()


def _cache_name(url):
    """Nom de fichier PNG canonique pour une URL."""
    h = hashlib.md5(url.encode()).hexdigest()
    return h + ".png"


def find_cached(url):
    """Cherche le PNG converti en cache (permanent puis tmp)."""
    name = _cache_name(url)
    for d in (DIR_PERM, DIR_TMP):
        path = os.path.join(d, name)
        if os.path.exists(path) and os.path.getsize(path) > 200:
            return path
    return None


def _to_png(src_path, dst_path):
    """Convertit src_path (JPG/WEBP/PNG) en PNG Enigma2-compatible via PIL."""
    try:
        from PIL import Image
        img = Image.open(src_path).convert("RGBA")
        img.save(dst_path, "PNG")
        return True
    except Exception as e:
        print("[Poster] PIL convert: %s" % e)
        # Si PIL échoue, essayer de copier si c'est déjà un PNG
        try:
            import shutil
            shutil.copy2(src_path, dst_path)
            return True
        except Exception:
            pass
    return False


def download(url, timeout=10):
    """Télécharge un poster et le convertit en PNG. Retourne chemin PNG ou None."""
    if not url or not (url.startswith("http://") or url.startswith("https://")):
        return None
    # Cache hit
    cached = find_cached(url)
    if cached:
        return cached
    # Télécharger
    raw_path = os.path.join(DIR_PERM, "raw_" + _cache_name(url))
    png_path  = os.path.join(DIR_PERM, _cache_name(url))
    try:
        ctx = ssl._create_unverified_context()
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 E2MultiPortal/1.0",
            "Accept": "image/*,*/*",
        })
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
            data = r.read()
        if len(data) < 200:
            return None
        with open(raw_path, "wb") as f:
            f.write(data)
        # Convertir en PNG
        if _to_png(raw_path, png_path):
            try: os.remove(raw_path)
            except: pass
            if os.path.exists(png_path) and os.path.getsize(png_path) > 200:
                return png_path
    except Exception as e:
        print("[Poster] Download %s: %s" % (url[:60], e))
    # Nettoyer
    for p in (raw_path,):
        try: os.remove(p)
        except: pass
    return None


def get_stream_icon(item):
    """Extrait l'URL image depuis un item stream (Xtream ou MAG)."""
    for key in ("stream_icon","cover","movie_image","backdrop_path",
                "screenshot_uri","thumbnail","logo","icon"):
        val = item.get(key, "")
        if val and isinstance(val, str) and (
                val.startswith("http://") or val.startswith("https://")):
            return val
    return ""


def show_pixmap(widget, path):
    """Affiche un PNG dans un widget Pixmap Enigma2."""
    try:
        from enigma import loadPNG
        if not path or not os.path.exists(path) or os.path.getsize(path) < 200:
            return
        png = loadPNG(path)
        if png and widget.instance:
            widget.instance.setPixmap(png)
            widget.instance.setScale(1)
            widget.show()
    except Exception as e:
        print("[Poster] show: %s" % e)


def load_and_show(widget, url):
    """Télécharge et affiche dans un thread."""
    def work():
        path = download(url)
        if path:
            show_pixmap(widget, path)
    threading.Thread(target=work, daemon=True).start()


def fetch_tmdb_movie(title, callback_info, callback_poster, existing_cover=False):
    import urllib.parse
    def work():
        try:
            q   = urllib.parse.quote(title[:60])
            url = "https://api.themoviedb.org/3/search/movie?api_key=%s&query=%s&language=fr-FR" % (TMDB_KEY, q)
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers={"User-Agent":"E2MultiPortal/1.0"})
            with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
                d = json.loads(r.read().decode("utf-8","ignore"))
            results = d.get("results",[])
            if not results: return
            r0 = results[0]
            gmap = {28:"Action",12:"Aventure",16:"Animation",35:"Comedie",
                    80:"Crime",99:"Documentaire",18:"Drame",10751:"Famille",
                    14:"Fantaisie",36:"Histoire",27:"Horreur",10402:"Musique",
                    9648:"Mystere",10749:"Romance",878:"Science-Fiction",
                    53:"Thriller",10752:"Guerre",37:"Western"}
            info = {
                "title":  r0.get("title", title),
                "year":   (r0.get("release_date","") or "")[:4],
                "rating": r0.get("vote_average", 0),
                "genre":  ", ".join(gmap.get(g,"") for g in r0.get("genre_ids",[])[:3] if g in gmap),
                "desc":   (r0.get("overview","") or "")[:340],
            }
            callback_info(info)
            pp = r0.get("poster_path","")
            if pp and not existing_cover:
                callback_poster("https://image.tmdb.org/t/p/w300" + pp)
            elif pp:
                threading.Thread(target=download,
                    args=("https://image.tmdb.org/t/p/w300"+pp,),daemon=True).start()
        except Exception as e:
            print("[Poster] TMDB movie '%s': %s" % (title, e))
    threading.Thread(target=work, daemon=True).start()


def fetch_tmdb_series(title, callback_info, callback_poster):
    import urllib.parse
    def work():
        try:
            q   = urllib.parse.quote(title[:60])
            url = "https://api.themoviedb.org/3/search/tv?api_key=%s&query=%s&language=fr-FR" % (TMDB_KEY, q)
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers={"User-Agent":"E2MultiPortal/1.0"})
            with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
                d = json.loads(r.read().decode("utf-8","ignore"))
            results = d.get("results",[])
            if not results: return
            r0 = results[0]
            info = {
                "title":  r0.get("name", title),
                "year":   (r0.get("first_air_date","") or "")[:4],
                "rating": r0.get("vote_average", 0),
                "genre":  "",
                "desc":   (r0.get("overview","") or "")[:340],
            }
            callback_info(info)
            pp = r0.get("poster_path","")
            if pp:
                callback_poster("https://image.tmdb.org/t/p/w300" + pp)
        except Exception as e:
            print("[Poster] TMDB series '%s': %s" % (title, e))
    threading.Thread(target=work, daemon=True).start()
