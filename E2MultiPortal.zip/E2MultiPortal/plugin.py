#!/usr/bin/python
# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
import threading

# ─── Démarrage immédiat du serveur web dès le chargement du plugin ────────────
# (sans avoir besoin d'ouvrir l'interface Enigma2)
_web_server = None

def _start_web_server_background():
    global _web_server
    try:
        from Plugins.Extensions.E2MultiPortal.webserver import WebServer
        _web_server = WebServer(port=8070)
        _web_server.start()
        print("[E2MultiPortal] Serveur web démarré sur le port 8070")
    except Exception as e:
        print(f"[E2MultiPortal] Erreur démarrage serveur web: {e}")

# Lancer dans un thread daemon au chargement du module
threading.Thread(target=_start_web_server_background, daemon=True).start()


# ─── Entrée Enigma2 ───────────────────────────────────────────────────────────

def main(session, **kwargs):
    """Point d'entrée principal"""
    print("[E2MultiPortal] Ouverture de l'interface...")
    try:
        from Plugins.Extensions.E2MultiPortal.main import E2MultiPortalMain
        return session.open(E2MultiPortalMain)
    except ImportError as e:
        print(f"[E2MultiPortal] ImportError: {e}")
        try:
            import sys, os
            plugin_dir = '/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal'
            if plugin_dir not in sys.path:
                sys.path.append(plugin_dir)
            from main import E2MultiPortalMain
            return session.open(E2MultiPortalMain)
        except Exception as e2:
            print(f"[E2MultiPortal] Import alternatif échoué: {e2}")
            try:
                from Screens.MessageBox import MessageBox
                session.open(MessageBox,
                    f"Erreur import E2MultiPortal:\n{str(e)}",
                    MessageBox.TYPE_ERROR)
            except:
                pass
    except Exception as e:
        print(f"[E2MultiPortal] Erreur générale: {e}")
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, f"Erreur: {str(e)[:60]}", MessageBox.TYPE_ERROR)
        except:
            pass
    return None


def Plugins(**kwargs):
    """Descripteur plugin Enigma2"""
    return [
        PluginDescriptor(
            name="E2MultiPortal",
            description="IPTV Client — MAG/Stalker & Xtream Codes",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main,
            needsRestart=False
        )
    ]
