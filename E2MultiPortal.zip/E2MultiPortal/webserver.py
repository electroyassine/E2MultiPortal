#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# E2MultiPortal v3.0 — Interface Web port 8070

import json
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

from .server_manager import (
    get_servers, get_active_server, add_server, update_server,
    delete_server, set_active_server, get_stats, format_mac
)
from .api_xtream import XtreamAPI
from .api_mag import MagAPI

HTML = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>E2MultiPortal v3.0</title>
<style>
:root{--bg:#0d1117;--panel:#16213e;--card:#1c2333;--header:#0f3460;--border:#30363d;
  --accent:#e94560;--ok:#27ae60;--err:#c0392b;--warn:#f39c12;--mag:#2980b9;
  --text:#e6edf3;--muted:#8b949e;--input:#0d1117}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh}
header{background:var(--header);border-bottom:2px solid var(--accent);height:60px;
  padding:0 24px;display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100}
.logo{display:flex;align-items:center;gap:12px}
.logo-box{width:38px;height:38px;border-radius:8px;background:var(--accent);
  display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;color:#fff}
.logo-name{font-size:1.2rem;font-weight:800}
.logo-name span{color:var(--accent)}
.logo-ver{font-size:.7rem;color:var(--muted)}
main{max-width:1200px;margin:0 auto;padding:1.5rem}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:1rem;margin-bottom:2rem}
.stat{background:var(--card);border:1px solid var(--border);border-radius:10px;
  padding:1.2rem 1.4rem;position:relative;overflow:hidden}
.stat::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px}
.s-total::before{background:var(--accent)}.s-xc::before{background:var(--warn)}
.s-mag::before{background:var(--mag)}.s-ok::before{background:var(--ok)}
.stat-val{font-size:2.4rem;font-weight:800;line-height:1}
.stat-lbl{color:var(--muted);font-size:.8rem;margin-top:4px}
.tabs{display:flex;gap:3px;margin-bottom:0}
.tab{padding:.5rem 1.4rem;border-radius:8px 8px 0 0;cursor:pointer;font-weight:700;
  font-size:.9rem;border:1px solid var(--border);border-bottom:none;
  background:var(--panel);color:var(--muted)}
.tab.active.xc{border-bottom:2px solid var(--warn);color:var(--warn);background:var(--card)}
.tab.active.mag{border-bottom:2px solid var(--mag);color:var(--mag);background:var(--card)}
.tab-panel{display:none}.tab-panel.active{display:block}
.section{background:var(--card);border:1px solid var(--border);
  border-radius:0 12px 12px 12px;padding:1.4rem;margin-bottom:1.2rem}
.section-hd{display:flex;align-items:center;gap:10px;font-size:.95rem;
  font-weight:700;margin-bottom:1.2rem}
.badge{padding:2px 10px;border-radius:20px;font-size:.72rem;font-weight:700}
.b-xc{background:#f39c1222;color:var(--warn);border:1px solid var(--warn)}
.b-mag{background:#2980b922;color:var(--mag);border:1px solid var(--mag)}
.form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem}
.fg{display:flex;flex-direction:column;gap:5px}
label{font-size:.75rem;color:var(--muted);font-weight:700;letter-spacing:.3px;text-transform:uppercase}
input{background:var(--input);border:1px solid var(--border);border-radius:7px;
  padding:.55rem .8rem;color:var(--text);font-size:.9rem;width:100%;transition:border-color .15s}
input:focus{outline:none;border-color:var(--accent)}
.btn-row{display:flex;gap:.7rem;margin-top:1.1rem;flex-wrap:wrap;align-items:center}
.btn{padding:.5rem 1.1rem;border-radius:7px;border:none;cursor:pointer;
  font-weight:700;font-size:.85rem;transition:opacity .15s}
.btn:hover{opacity:.85}.btn:disabled{opacity:.3;cursor:not-allowed}
.btn-test{background:var(--warn);color:#000}
.btn-save{background:var(--ok);color:#fff}
.btn-clear{background:var(--border);color:var(--text)}
.smsg{padding:.45rem .9rem;border-radius:6px;font-size:.82rem;
  display:none;align-items:center;gap:7px}
.smsg.show{display:flex}
.smsg.ok{background:#27ae6022;color:#27ae60;border:1px solid #27ae60}
.smsg.err{background:#c0392b22;color:#e74c3c;border:1px solid #c0392b}
.smsg.load{background:#f39c1222;color:var(--warn);border:1px solid var(--warn)}
.srv-table{width:100%;border-collapse:collapse;margin-top:.8rem}
.srv-table th{text-align:left;padding:.5rem .9rem;font-size:.75rem;
  color:var(--muted);border-bottom:1px solid var(--border);font-weight:700}
.srv-table td{padding:.65rem .9rem;border-bottom:1px solid var(--border);
  font-size:.85rem;vertical-align:middle}
.srv-table tr:last-child td{border-bottom:none}
.srv-table tr:hover td{background:#ffffff07}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block;margin-right:5px}
.dot-ok{background:var(--ok)}.dot-act{background:#f39c12}.dot-unk{background:var(--muted)}
.sname{font-weight:700}
.btn-edit{background:var(--border);color:var(--text);padding:.3rem .7rem;font-size:.75rem;margin-right:5px}
.btn-del{background:var(--err);color:#fff;padding:.3rem .7rem;font-size:.75rem}
.btn-act{background:var(--ok);color:#fff;padding:.3rem .7rem;font-size:.75rem;margin-right:5px}
.empty{text-align:center;padding:2.5rem;color:var(--muted)}
footer{text-align:center;padding:1.2rem;color:var(--muted);
  font-size:.78rem;border-top:1px solid var(--border);margin-top:2rem}
</style>
</head>
<body>
<header>
  <div class="logo">
    <div class="logo-box">E2</div>
    <div>
      <div class="logo-name">E2<span>Multi</span>Portal</div>
      <div class="logo-ver">v3.0 — Gestion des serveurs IPTV</div>
    </div>
  </div>
  <div style="text-align:right;font-size:.82rem">
    <div style="color:var(--muted)">Port web : <strong style="color:var(--text)">8070</strong></div>
    <div id="clock" style="color:var(--muted)"></div>
  </div>
</header>
<main>
<div class="stats">
  <div class="stat s-total"><div class="stat-val" id="st-total">—</div><div class="stat-lbl">Total serveurs</div></div>
  <div class="stat s-xc"><div class="stat-val" id="st-xc">—</div><div class="stat-lbl">Xtream Codes</div></div>
  <div class="stat s-mag"><div class="stat-val" id="st-mag">—</div><div class="stat-lbl">MAG / Portail</div></div>
  <div class="stat s-ok"><div class="stat-val" id="st-ok">—</div><div class="stat-lbl">Serveur actif</div></div>
</div>
<div class="tabs">
  <div class="tab xc active" onclick="switchTab('xc')">Xtream Codes</div>
  <div class="tab mag" onclick="switchTab('mag')">MAG / Portail</div>
</div>
<div class="tab-panel active" id="tp-xc">
  <div class="section">
    <div class="section-hd">Ajouter / Modifier <span class="badge b-xc">XTREAM</span></div>
    <div class="form-grid">
      <div class="fg"><label>Nom</label><input type="text" id="xc-name" placeholder="Mon serveur Xtream"></div>
      <div class="fg" style="grid-column:span 2"><label>Host (URL)</label><input type="text" id="xc-host" placeholder="http://monserveur.com"></div>
      <div class="fg"><label>Port</label><input type="number" id="xc-port" value="80"></div>
      <div class="fg"><label>Utilisateur</label><input type="text" id="xc-user" placeholder="username"></div>
      <div class="fg"><label>Mot de passe</label><input type="password" id="xc-pass" placeholder="password"></div>
    </div>
    <div class="btn-row">
      <button class="btn btn-test" onclick="testXC()">Tester</button>
      <button class="btn btn-save" id="xc-save-btn" disabled onclick="saveXC()">Enregistrer</button>
      <button class="btn btn-clear" onclick="clearXC()">Effacer</button>
      <div class="smsg" id="xc-msg"></div>
    </div>
  </div>
  <div class="section">
    <div class="section-hd">Serveurs Xtream <span class="badge b-xc" id="xc-cnt">0</span></div>
    <div id="xc-list"></div>
  </div>
</div>
<div class="tab-panel" id="tp-mag">
  <div class="section">
    <div class="section-hd">Ajouter / Modifier <span class="badge b-mag">MAG</span></div>
    <div class="form-grid">
      <div class="fg"><label>Nom</label><input type="text" id="mag-name" placeholder="Mon portail MAG"></div>
      <div class="fg" style="grid-column:span 2"><label>Host / URL</label><input type="text" id="mag-host" placeholder="http://portail.example.com"></div>
      <div class="fg"><label>Adresse MAC</label><input type="text" id="mag-mac" placeholder="00:1A:79:XX:XX:XX"></div>
    </div>
    <div class="btn-row">
      <button class="btn btn-test" onclick="testMAG()">Tester</button>
      <button class="btn btn-save" id="mag-save-btn" disabled onclick="saveMAG()">Enregistrer</button>
      <button class="btn btn-clear" onclick="clearMAG()">Effacer</button>
      <div class="smsg" id="mag-msg"></div>
    </div>
  </div>
  <div class="section">
    <div class="section-hd">Portails MAG <span class="badge b-mag" id="mag-cnt">0</span></div>
    <div id="mag-list"></div>
  </div>
</div>
</main>
<footer>E2MultiPortal v3.0</footer>
<script>
function tick(){document.getElementById('clock').textContent=new Date().toLocaleString('fr-FR')}
setInterval(tick,1000);tick();
function switchTab(t){
  document.querySelectorAll('.tab').forEach((el,i)=>{
    el.classList.remove('active');
    if((i===0&&t==='xc')||(i===1&&t==='mag'))el.classList.add('active');
  });
  document.querySelectorAll('.tab-panel').forEach(el=>el.classList.remove('active'));
  document.getElementById('tp-'+t).classList.add('active');
}
async function loadAll(){
  try{
    const r=await fetch('/stats');const d=await r.json();
    document.getElementById('st-total').textContent=(d.xtream?.total||0)+(d.mag?.total||0);
    document.getElementById('st-xc').textContent=d.xtream?.total||0;
    document.getElementById('st-mag').textContent=d.mag?.total||0;
    const act=d.active;
    document.getElementById('st-ok').textContent=act?act.name.substring(0,12):'—';
    renderList('xc-list',d.xtream?.servers||[],'xtream','xc-cnt');
    renderList('mag-list',d.mag?.servers||[],'mag','mag-cnt');
  }catch(e){console.error(e)}
}
function renderList(cid,servers,type,cntId){
  document.getElementById(cntId).textContent=servers.length;
  const el=document.getElementById(cid);
  if(!servers.length){el.innerHTML='<div class="empty">Aucun serveur</div>';return;}
  el.innerHTML=`<table class="srv-table">
    <tr><th>Statut</th><th>Nom</th><th>Host</th><th>Details</th><th>Actions</th></tr>
    ${servers.map(s=>{
      serversCache[s.id]=s;
      const dc=s.active?'dot-act':'dot-unk';
      const lbl=s.active?'ACTIF':'Inactif';
      const det=type==='xtream'?`${s.port||''} / ${s.username||''}`:`MAC: ${s.mac||''}`;
      const ef=type==='xtream'?`editXC('${s.id}')`:`editMAG('${s.id}')`;
      return `<tr>
        <td><span class="dot ${dc}"></span>${lbl}</td>
        <td><div class="sname">${s.name||s.host}</div></td>
        <td style="font-size:.8rem;color:var(--muted)">${s.host}</td>
        <td style="font-size:.78rem;color:var(--muted)">${det}</td>
        <td>
          <button class="btn btn-act" onclick="activate('${s.id}')">Activer</button>
          <button class="btn btn-edit" onclick="${ef}">Editer</button>
          <button class="btn btn-del" onclick="del('${s.id}')">Suppr.</button>
        </td>
      </tr>`;
    }).join('')}
  </table>`;
}
function setMsg(id,type,msg){const el=document.getElementById(id);el.className='smsg show '+type;el.textContent=msg;}
let editIdXC=null, editIdMAG=null;
let expXC='', expMAG='';
let serversCache={};
async function testXC(){
  setMsg('xc-msg','load','Test en cours...');document.getElementById('xc-save-btn').disabled=true;
  const d={host:document.getElementById('xc-host').value,port:document.getElementById('xc-port').value,
    username:document.getElementById('xc-user').value,password:document.getElementById('xc-pass').value};
  try{const r=await fetch('/test_xtream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
    const j=await r.json();
    if(j.success){setMsg('xc-msg','ok','OK - '+j.info);document.getElementById('xc-save-btn').disabled=false;expXC=j.expiration||'';}
    else setMsg('xc-msg','err','ERREUR: '+j.error);
  }catch(e){setMsg('xc-msg','err','Erreur reseau')}
}
async function saveXC(){
  const d={name:document.getElementById('xc-name').value,host:document.getElementById('xc-host').value,
    port:document.getElementById('xc-port').value,username:document.getElementById('xc-user').value,
    password:document.getElementById('xc-pass').value,expiration:expXC};
  const isEdit=!!editIdXC;
  const url=isEdit?'/update_xtream':'/save_xtream';
  if(isEdit) d.id=editIdXC;
  try{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
    const j=await r.json();
    if(j.success){setMsg('xc-msg','ok',isEdit?'Mis a jour!':'Enregistre!');clearXC();loadAll();}
    else setMsg('xc-msg','err',j.message||'Erreur');
  }catch(e){setMsg('xc-msg','err','Erreur reseau')}
}
function clearXC(){['xc-name','xc-host','xc-user','xc-pass'].forEach(i=>document.getElementById(i).value='');
  document.getElementById('xc-port').value='80';document.getElementById('xc-save-btn').disabled=true;
  document.getElementById('xc-msg').className='smsg';
  expXC='';
  editIdXC=null;document.getElementById('xc-save-btn').textContent='Enregistrer';}
function editXC(id){switchTab('xc');
  const s=serversCache[id]||{};
  document.getElementById('xc-name').value=s.name||'';document.getElementById('xc-host').value=s.host||'';
  document.getElementById('xc-port').value=s.port||'80';document.getElementById('xc-user').value=s.username||'';
  document.getElementById('xc-pass').value=s.password||'';
  editIdXC=s.id;
  expXC=s.expiration||'';
  document.getElementById('xc-save-btn').disabled=false;
  document.getElementById('xc-save-btn').textContent='Mettre a jour';
  setMsg('xc-msg','load','Mode edition -- "Mettre a jour" pour enregistrer (ou "Tester" pour verifier)');}
async function testMAG(){
  setMsg('mag-msg','load','Test en cours...');document.getElementById('mag-save-btn').disabled=true;
  const d={host:document.getElementById('mag-host').value,mac:document.getElementById('mag-mac').value};
  try{const r=await fetch('/test_mag',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
    const j=await r.json();
    if(j.success){setMsg('mag-msg','ok','OK - '+j.info);document.getElementById('mag-save-btn').disabled=false;expMAG=j.expiration||'';}
    else setMsg('mag-msg','err','ERREUR: '+j.error);
  }catch(e){setMsg('mag-msg','err','Erreur reseau')}
}
async function saveMAG(){
  const d={name:document.getElementById('mag-name').value,host:document.getElementById('mag-host').value,
    mac:document.getElementById('mag-mac').value,expiration:expMAG};
  const isEdit=!!editIdMAG;
  const url=isEdit?'/update_mag':'/save_mag';
  if(isEdit) d.id=editIdMAG;
  try{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
    const j=await r.json();
    if(j.success){setMsg('mag-msg','ok',isEdit?'Mis a jour!':'Enregistre!');clearMAG();loadAll();}
    else setMsg('mag-msg','err',j.message||'Erreur');
  }catch(e){setMsg('mag-msg','err','Erreur reseau')}
}
function clearMAG(){['mag-name','mag-host','mag-mac'].forEach(i=>document.getElementById(i).value='');
  document.getElementById('mag-save-btn').disabled=true;document.getElementById('mag-msg').className='smsg';
  expMAG='';
  editIdMAG=null;document.getElementById('mag-save-btn').textContent='Enregistrer';}
function editMAG(id){switchTab('mag');
  const s=serversCache[id]||{};
  document.getElementById('mag-name').value=s.name||'';document.getElementById('mag-host').value=s.host||'';
  document.getElementById('mag-mac').value=s.mac||'';
  editIdMAG=s.id;
  expMAG=s.expiration||'';
  document.getElementById('mag-save-btn').disabled=false;
  document.getElementById('mag-save-btn').textContent='Mettre a jour';
  setMsg('mag-msg','load','Mode edition -- "Mettre a jour" pour enregistrer (ou "Tester" pour verifier)');}
async function activate(id){
  await fetch('/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
  loadAll();}
async function del(id){
  if(!confirm('Supprimer ce serveur ?'))return;
  await fetch('/delete_server',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
  loadAll();}
loadAll();setInterval(loadAll,30000);
</script>
</body>
</html>"""


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass

    def _json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def _html(self, body):
        b = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", len(b))
        self.end_headers()
        self.wfile.write(b)

    def _read_json(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n)) if n else {}

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/":
            self._html(HTML)
        elif p == "/stats":
            s = get_stats()
            s["active"] = get_active_server()
            self._json(s)
        elif p == "/servers":
            self._json(get_servers())
        elif p == "/status":
            self._json({"plugin": "E2MultiPortal", "version": "3.0", "port": 8070,
                        "active": get_active_server()})
        else:
            self.send_error(404)

    def do_POST(self):
        p = self.path.split("?")[0]
        d = self._read_json()

        if p == "/test_xtream":
            try:
                # Sécuriser le port : string vide ou None → 80
                raw_port = d.get("port", "80")
                try:
                    port = int(str(raw_port).strip()) if str(raw_port).strip() else 80
                except (ValueError, TypeError):
                    port = 80
                # Ordre correct : host, username, password, port
                api    = XtreamAPI(d.get("host",""), d.get("username",""), d.get("password",""), port)
                result = api.test_connection()
                if result.get("success"):
                    exp = result.get("expiration", "")
                    try:
                        if exp and str(exp).strip().isdigit():
                            exp = datetime.fromtimestamp(int(exp)).strftime("%d/%m/%Y")
                    except:
                        pass
                    status = result.get("status", "active")
                    info   = f"OK [{status}]"
                    if exp and exp != "N/A":
                        info += f" — Expire: {exp}"
                    self._json({"success": True, "info": info, "expiration": exp if exp != "N/A" else ""})
                else:
                    self._json({"success": False, "error": result.get("message","Erreur inconnue")})
            except Exception as e:
                self._json({"success": False, "error": str(e)[:120]})

        elif p == "/save_xtream":
            raw_port = d.get("port", "80")
            try:
                port = int(str(raw_port).strip()) if str(raw_port).strip() else 80
            except (ValueError, TypeError):
                port = 80
            r = add_server({
                "type":     "xtream",
                "name":     d.get("name","") or d.get("host",""),
                "host":     d.get("host",""),
                "port":     port,
                "username": d.get("username",""),
                "password": d.get("password",""),
                "expiration": d.get("expiration",""),
            })
            self._json(r)

        elif p == "/update_xtream":
            raw_port = d.get("port", "80")
            try:
                port = int(str(raw_port).strip()) if str(raw_port).strip() else 80
            except (ValueError, TypeError):
                port = 80
            r = update_server(d.get("id",""), {
                "name":     d.get("name",""),
                "host":     d.get("host",""),
                "port":     port,
                "username": d.get("username",""),
                "password": d.get("password",""),
                "expiration": d.get("expiration",""),
            })
            self._json(r)

        elif p == "/test_mag":
            try:
                api    = MagAPI(d.get("host",""), d.get("mac",""))
                result = api.test_connection()   # méthode correcte
                if result.get("success"):
                    info = result.get("message","Portail MAG accessible")
                    fw   = result.get("firmware","")
                    if fw:
                        info += f" ({fw})"
                    exp = result.get("expiration", "")
                    if exp:
                        info += f" — Expire: {exp}"
                    self._json({"success": True, "info": info, "expiration": exp})
                else:
                    self._json({"success": False, "error": result.get("message","Portail inaccessible")})
            except Exception as e:
                self._json({"success": False, "error": str(e)[:120]})

        elif p == "/save_mag":
            r = add_server({
                "type": "mag",
                "name": d.get("name","") or d.get("host",""),
                "host": d.get("host",""),
                "mac":  d.get("mac",""),
                "expiration": d.get("expiration",""),
            })
            self._json(r)

        elif p == "/update_mag":
            r = update_server(d.get("id",""), {
                "name": d.get("name",""),
                "host": d.get("host",""),
                "mac":  d.get("mac",""),
                "expiration": d.get("expiration",""),
            })
            self._json(r)

        elif p == "/activate":
            r = set_active_server(d.get("id",""))
            self._json(r)

        else:
            self.send_error(404)

    def do_DELETE(self):
        if self.path.split("?")[0] == "/delete_server":
            d = self._read_json()
            r = delete_server(d.get("id", ""))
            self._json(r)
        else:
            self.send_error(404)


class WebServer:
    def __init__(self, port=8070):
        self._port   = port
        self._server = None

    def start(self):
        try:
            self._server = HTTPServer(("0.0.0.0", self._port), _Handler)
            threading.Thread(target=self._server.serve_forever, daemon=True).start()
            print("[E2MultiPortal] Web server on port %d" % self._port)
        except Exception as e:
            print("[E2MultiPortal] Web server error:", e)

    def stop(self):
        if self._server:
            self._server.shutdown()
