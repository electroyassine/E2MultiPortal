# -*- coding: utf-8 -*-
"""
_crypto.py - AES-128-CBC (FIPS-197) en Python pur, sans dependance externe.

Utilise par les modules du plugin pour decoder leur code source au moment
de l'import (voir le wrapper genere dans chaque module .py).

Implementation volontairement compacte et autonome : aucune bibliotheque
externe requise (compatible avec n'importe quelle box / version de Python).
"""
import base64

# ── Cle partagee (AES-128 = 16 octets) ───────────────────────────────────────
# NB: la cle est forcement presente dans le code (necessaire pour dechiffrer
# a l'execution). Cela offre une protection "dissuasive" contre la lecture
# occasionnelle, pas une protection cryptographique au sens fort.
_KEY = bytes([
    0x4E, 0x32, 0x4D, 0x75, 0x6C, 0x74, 0x69, 0x50,
    0x6F, 0x72, 0x74, 0x61, 0x6C, 0x21, 0x21, 0x32,
])

# ── Tables AES standard (FIPS-197) ───────────────────────────────────────────
_SBOX = [
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
]
_INV_SBOX = [0]*256
for _i, _v in enumerate(_SBOX):
    _INV_SBOX[_v] = _i

_RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36]


def _xtime(a):
    a <<= 1
    if a & 0x100:
        a ^= 0x11B
    return a & 0xFF


def _gmul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        a = _xtime(a)
        b >>= 1
    return p & 0xFF


def _key_expansion(key):
    nk = 4  # AES-128 : 4 mots de 32 bits
    nr = 10
    w = [list(key[i*4:i*4+4]) for i in range(nk)]
    for i in range(nk, 4*(nr+1)):
        temp = list(w[i-1])
        if i % nk == 0:
            temp = temp[1:] + temp[:1]
            temp = [_SBOX[b] for b in temp]
            temp[0] ^= _RCON[i//nk - 1]
        w.append([w[i-nk][j] ^ temp[j] for j in range(4)])
    # Regroupe en round keys (16 octets chacune)
    round_keys = []
    for r in range(nr+1):
        rk = []
        for c in range(4):
            rk += w[r*4+c]
        round_keys.append(rk)
    return round_keys


def _add_round_key(state, rk):
    return [state[i] ^ rk[i] for i in range(16)]


def _inv_sub_bytes(state):
    return [_INV_SBOX[b] for b in state]


def _inv_shift_rows(state):
    # state est en ordre colonne-major (comme AES standard)
    s = state
    return [
        s[0],  s[13], s[10], s[7],
        s[4],  s[1],  s[14], s[11],
        s[8],  s[5],  s[2],  s[15],
        s[12], s[9],  s[6],  s[3],
    ]


def _inv_mix_columns(state):
    out = [0]*16
    for c in range(4):
        col = state[c*4:c*4+4]
        out[c*4+0] = _gmul(col[0],0x0e)^_gmul(col[1],0x0b)^_gmul(col[2],0x0d)^_gmul(col[3],0x09)
        out[c*4+1] = _gmul(col[0],0x09)^_gmul(col[1],0x0e)^_gmul(col[2],0x0b)^_gmul(col[3],0x0d)
        out[c*4+2] = _gmul(col[0],0x0d)^_gmul(col[1],0x09)^_gmul(col[2],0x0e)^_gmul(col[3],0x0b)
        out[c*4+3] = _gmul(col[0],0x0b)^_gmul(col[1],0x0d)^_gmul(col[2],0x09)^_gmul(col[3],0x0e)
    return out


def _sub_bytes(state):
    return [_SBOX[b] for b in state]


def _shift_rows(state):
    s = state
    return [
        s[0],  s[5],  s[10], s[15],
        s[4],  s[9],  s[14], s[3],
        s[8],  s[13], s[2],  s[7],
        s[12], s[1],  s[6],  s[11],
    ]


def _mix_columns(state):
    out = [0]*16
    for c in range(4):
        col = state[c*4:c*4+4]
        out[c*4+0] = _gmul(col[0],2)^_gmul(col[1],3)^col[2]^col[3]
        out[c*4+1] = col[0]^_gmul(col[1],2)^_gmul(col[2],3)^col[3]
        out[c*4+2] = col[0]^col[1]^_gmul(col[2],2)^_gmul(col[3],3)
        out[c*4+3] = _gmul(col[0],3)^col[1]^col[2]^_gmul(col[3],2)
    return out


def _to_state(block):
    """16 octets -> ordre colonne-major utilise par les fonctions ci-dessus."""
    state = [0]*16
    for c in range(4):
        for r in range(4):
            state[c*4+r] = block[r*4+c] if False else block[c*4+r]
    return list(block)  # block est deja en ordre lineaire compatible


def _encrypt_block(block, round_keys):
    state = _add_round_key(list(block), round_keys[0])
    for rnd in range(1, 10):
        state = _sub_bytes(state)
        state = _shift_rows(state)
        state = _mix_columns(state)
        state = _add_round_key(state, round_keys[rnd])
    state = _sub_bytes(state)
    state = _shift_rows(state)
    state = _add_round_key(state, round_keys[10])
    return bytes(state)


def _decrypt_block(block, round_keys):
    state = _add_round_key(list(block), round_keys[10])
    for rnd in range(9, 0, -1):
        state = _inv_shift_rows(state)
        state = _inv_sub_bytes(state)
        state = _add_round_key(state, round_keys[rnd])
        state = _inv_mix_columns(state)
    state = _inv_shift_rows(state)
    state = _inv_sub_bytes(state)
    state = _add_round_key(state, round_keys[0])
    return bytes(state)


def _pkcs7_pad(data, block=16):
    n = block - (len(data) % block)
    return data + bytes([n])*n


def _pkcs7_unpad(data):
    n = data[-1]
    if n < 1 or n > 16:
        raise ValueError("Padding invalide")
    return data[:-n]


def encrypt(plaintext_bytes, iv):
    """AES-128-CBC : retourne IV (16o) + ciphertext, encode en base64 (str)."""
    rk = _key_expansion(_KEY)
    data = _pkcs7_pad(plaintext_bytes)
    out = bytearray()
    prev = iv
    for i in range(0, len(data), 16):
        block = bytes(a ^ b for a, b in zip(data[i:i+16], prev))
        enc = _encrypt_block(block, rk)
        out += enc
        prev = enc
    return base64.b64encode(iv + bytes(out)).decode("ascii")


def decrypt(b64_payload):
    """Inverse de encrypt() : retourne le texte source (str, utf-8)."""
    raw = base64.b64decode(b64_payload)
    iv, data = raw[:16], raw[16:]
    rk = _key_expansion(_KEY)
    out = bytearray()
    prev = iv
    for i in range(0, len(data), 16):
        block = data[i:i+16]
        dec = _decrypt_block(block, rk)
        out += bytes(a ^ b for a, b in zip(dec, prev))
        prev = block
    return _pkcs7_unpad(bytes(out)).decode("utf-8")
