# E2MultiPortal — Notes de mise à jour (v1.1.18)

Date : 15/06/2026

## Menu principal — bouton "MISE A JOUR" (jaune)

- **EXIT** est déplacé à gauche du menu (position 40,970).
- Un nouveau bouton **jaune "MISE A JOUR"** apparaît juste à côté
  (position 310,970).
- Appui sur le bouton (ou la touche **JAUNE**) :
  1. Récupère `version.json` depuis
     `https://raw.githubusercontent.com/electroyassine/E2MultiPortal/refs/heads/main/version.json`.
  2. Compare avec la version installée.
  3. Si une version plus récente existe → message **Oui/Non** "Nouvelle
     version disponible : vX.X.X ... Installer maintenant ?".
  4. Si **Oui** → télécharge `E2MultiPortal.zip` depuis `main`, remplace
     l'installation dans `/usr/lib/enigma2/python/Plugins/Extensions/`, puis
     propose un redémarrage Enigma2 (`init 4` puis `init 3`).
  5. Si déjà à jour → message de confirmation.

⚠️ Pour que cette fonctionnalité marche, **`version.json` doit aussi être
présent à la racine du dépôt** (branche `main`), en plus de celui inclus
dans `E2MultiPortal.zip`. Un exemplaire `version.json` (identique à celui du
zip) est fourni séparément — committez-le à la racine du repo.

## Rappel des correctifs précédents (toujours inclus dans ce paquet)

- v1.1.17 : suppression des boutons de pagination VOD.
- v1.1.16 : recherche dédiée via bouton bleu "RECHERCHE".
- v1.1.15 : lecture continue lors du retour à la liste.
- v1.1.14 : bouton bleu PLAYER (CONFIG) pour choisir le moteur de lecture.
- v1.1.13 → v1.1.0 : voir versions précédentes.

## Fichiers modifiés dans ce paquet

- `main.py` : EXIT déplacé, nouveau bouton `key_yellow` (MISE A JOUR),
  `check_update()`, `_check_update_thread()`, `_update_confirmed()`,
  `_update_done()`, `_restart_confirmed()`, comparaison de versions.
- `version.json` : version → `1.1.18` + changelog.

## Installation

1. Remplacer entièrement le dossier du plugin sur la box (ex.
   `/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal`) par le contenu
   de `E2MultiPortal_fixed/` de ce zip.
2. Redémarrer Enigma2 (`init 4 && init 3` ou via le menu).
3. Côté dépôt GitHub : committer ce nouveau `version.json` aussi à la
   racine du dépôt (en plus de `E2MultiPortal.zip`), pour que le bouton
   "MISE A JOUR" puisse détecter les futures versions.
