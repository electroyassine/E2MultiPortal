#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
PlaylistScreen - Liste + activation uniquement (pas d'ajout ici)
Grille 4x3 | Onglets MAG / XTREAM
"""

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from enigma import gRGB
import json
import os
from datetime import datetime

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"
CONFIG_FILE = "/etc/enigma2/E2MultiPortal/servers.json"


class PlaylistScreen(Screen):
    """Grille 4x3 — sélection et activation serveur MAG ou Xtream"""

    GRID_COLS = 4
    GRID_ROWS = 3
    PER_PAGE  = 12

    GX, GY   = 100, 215
    CW, CH   = 400, 178
    SX, SY   = 28,  16

    IW, IH   = 280, 90
    IX_OFF   = (CW - IW) // 2
    IY_OFF   = 12
    LY_OFF   = CH - 40
    LH       = 36

    ICON_MAG    = PLUGIN_PATH + "/skins/iconS4.png"
    ICON_XTREAM = PLUGIN_PATH + "/skins/iconX4.png"
    TABS = ["MAG", "XTREAM"]

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"]    = Label("PLAYLIST")
        self["tab_info"] = Label("")
        self["subtitle"] = Label("")
        self["pg_info"]  = Label("")
        self["status"]   = Label("")

        self["btn_connect"] = Button("ACTIVER")
        self["btn_exit"]    = Button("EXIT")
        self["btn_tab_l"]   = Button("MAG")
        self["btn_tab_r"]   = Button("XTREAM")

        self.grid_bgs  = []
        self.grid_pxs  = []
        self.grid_lbls = []
        for i in range(self.PER_PAGE):
            self["gb_%d" % i] = Pixmap()
            self["gp_%d" % i] = Pixmap()
            self["gl_%d" % i] = Label("")
            self.grid_bgs.append("gb_%d" % i)
            self.grid_pxs.append("gp_%d" % i)
            self.grid_lbls.append("gl_%d" % i)

        self.tab      = 0
        self.all_srv  = []
        self.servers  = []
        self.sel      = 0
        self.page     = 0

        self.skin = self._gen_skin()
        self._load()

        self.onLayoutFinish.append(self._refresh)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up":     self.keyUp,
                "down":   self.keyDown,
                "left":   self.keyLeft,
                "right":  self.keyRight,
                "ok":     self.do_connect,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.do_connect,
                "yellow": self._switch_tab,
                "blue":   self._switch_tab,
            }, -1
        )

    def _gen_skin(self):
        cells = ""
        for row in range(self.GRID_ROWS):
            for col in range(self.GRID_COLS):
                i  = row * self.GRID_COLS + col
                x  = self.GX + col * (self.CW + self.SX)
                y  = self.GY + row * (self.CH + self.SY)
                cells += """
    <widget name="gb_%d" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" />
    <widget name="gp_%d" position="%d,%d" size="%d,%d" zPosition="2" transparent="1" alphatest="on" scale="1" />
    <widget name="gl_%d" position="%d,%d" size="%d,%d" font="Bold;28" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="3" />""" % (
                    i, x, y, self.CW, self.CH,
                    i, x+self.IX_OFF, y+self.IY_OFF, self.IW, self.IH,
                    i, x, y+self.LY_OFF, self.CW, self.LH)

        return """
<screen name="PlaylistScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="#010103">
    <ePixmap position="0,0" size="1920,1080" pixmap="%s/skins/config.png" zPosition="-1"/>
    <widget name="title"    position="0,25"    size="1920,65" font="Bold;52" halign="center" foregroundColor="#ebeb0c" transparent="1"/>
    <widget name="tab_info" position="0,88"    size="1920,40" font="Bold;28" halign="center" foregroundColor="#3498db" transparent="1"/>
    <eLabel position="100,130" size="1720,2" backgroundColor="#444"/>
    <widget name="subtitle" position="100,135" size="1720,34" font="Regular;23" halign="center" foregroundColor="#aaa" transparent="1"/>
    <widget name="pg_info"  position="100,170" size="1720,30" font="Regular;20" halign="center" foregroundColor="#777" transparent="1"/>
    %s
    <widget name="status"   position="100,868" size="1720,38" font="Bold;24" halign="center" foregroundColor="#d0de07" transparent="1"/>
    <widget name="btn_tab_l"  position="100,914"  size="190,50" font="Bold;22" halign="center" backgroundColor="#2980b9" foregroundColor="#fff"/>
    <widget name="btn_tab_r"  position="1630,914" size="190,50" font="Bold;22" halign="center" backgroundColor="#f39c12" foregroundColor="#000"/>
    <widget name="btn_connect" position="640,974" size="250,52" font="Bold;24" halign="center" backgroundColor="#27ae60" foregroundColor="#fff"/>
    <widget name="btn_exit"   position="1030,974" size="250,52" font="Bold;24" halign="center" backgroundColor="#e74c3c" foregroundColor="#fff"/>
</screen>""" % (PLUGIN_PATH, cells)

    def _load(self):
        try:
            if not os.path.exists(CONFIG_FILE):
                self.all_srv = []
            else:
                with open(CONFIG_FILE) as f:
                    d = json.load(f)
                self.all_srv = d.get("servers", []) if isinstance(d, dict) else d
            for s in self.all_srv:
                s.setdefault("active", False)
                s.setdefault("name",   "Serveur")
                if not s.get("host") and s.get("url"):
                    s["host"] = s["url"]
                if s.get("type") == "stalker":
                    s["type"] = "mag"
                s.setdefault("type", "mag")
        except Exception as e:
            print("[Playlist] Load: %s" % e)
            self.all_srv = []
        self._filter()

    def _filter(self):
        tt = "mag" if self.tab == 0 else "xtream"
        self.servers = [s for s in self.all_srv if s.get("type") == tt]
        ai = next((i for i, s in enumerate(self.servers) if s.get("active")), -1)
        if ai >= 0:
            self.sel  = ai
            self.page = ai // self.PER_PAGE
        else:
            self.sel  = 0
            self.page = 0
        n  = len(self.servers)
        ac = sum(1 for s in self.servers if s.get("active"))
        tn = self.TABS[self.tab]
        if n:
            self["status"].setText("%d playlist(s) %s  |  %d active" % (n, tn, ac))
        else:
            self["status"].setText("Aucune playlist %s — Ajoutez via SERVERS ou interface web" % tn)

    def _save(self):
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump({"servers": self.all_srv, "last_updated": str(datetime.now())},
                          f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print("[Playlist] Save: %s" % e)
            return False

    def _refresh(self):
        is_mag = self.tab == 0
        tn = self.TABS[self.tab]
        if is_mag:
            self["tab_info"].setText("  MAG / Portail         Xtream Codes")
            self["btn_tab_l"].setText("MAG")
            self["btn_tab_r"].setText("XTREAM")
        else:
            self["tab_info"].setText("  MAG / Portail         Xtream Codes")
            self["btn_tab_l"].setText("XTREAM")
            self["btn_tab_r"].setText("MAG")
        self["subtitle"].setText(
            "Playlists %s  |  Jaune/Bleu = onglet  |  OK/Vert = Activer" % tn)
        tp = self._tp()
        if tp > 1:
            self["pg_info"].setText("Page %d/%d  (%d playlist(s))" % (self.page+1, tp, len(self.servers)))
        else:
            self["pg_info"].setText("%d playlist(s) %s" % (len(self.servers), tn))
        self._draw()

    def _draw(self):
        ps    = self.servers[self.page*self.PER_PAGE:(self.page+1)*self.PER_PAGE]
        g0    = self.page * self.PER_PAGE
        ipath = self.ICON_MAG if self.tab == 0 else self.ICON_XTREAM

        for i in range(self.PER_PAGE):
            bg  = self.grid_bgs[i]
            px  = self.grid_pxs[i]
            lbl = self.grid_lbls[i]

            if i < len(ps):
                s      = ps[i]
                gi     = g0 + i
                active = s.get("active", False)
                sel    = (gi == self.sel)
                name   = s.get("name", "?")
                if len(name) > 26:
                    name = name[:23] + "..."

                self[bg].show()
                if self[bg].instance:
                    if sel:
                        self[bg].instance.setBackgroundColor(gRGB(0x3c, 0x4b, 0x32))
                        self[bg].instance.setBorderColor(gRGB(0x64, 0xFF, 0x64))
                    elif active:
                        self[bg].instance.setBackgroundColor(gRGB(0x1e, 0x46, 0x1e))
                        self[bg].instance.setBorderColor(gRGB(0x27, 0xAE, 0x60))
                    else:
                        self[bg].instance.setBackgroundColor(gRGB(0x2a, 0x2a, 0x36))
                        self[bg].instance.setBorderColor(gRGB(0x55, 0x55, 0x55))

                try:
                    if os.path.exists(ipath) and self[px].instance:
                        self[px].instance.setPixmapFromFile(ipath)
                        self[px].instance.setScale(1)
                        self[px].show()
                    else:
                        self[px].hide()
                except:
                    self[px].hide()

                self[lbl].setText(("  " if active else "  ") + name)
                if self[lbl].instance:
                    self[lbl].instance.setForegroundColor(
                        gRGB(0xFF, 0xFF, 0x64) if sel else
                        gRGB(0x00, 0xFF, 0x00) if active else
                        gRGB(0xCC, 0xCC, 0xCC))
                self[lbl].show()
            else:
                if not self.servers and self.page == 0 and i == 0:
                    self[bg].show()
                    if self[bg].instance:
                        self[bg].instance.setBackgroundColor(gRGB(0x2d, 0x2d, 0x37))
                    self[px].hide()
                    self[lbl].setText("Ajoutez via SERVERS")
                    if self[lbl].instance:
                        self[lbl].instance.setForegroundColor(gRGB(0x77, 0x77, 0x77))
                    self[lbl].show()
                else:
                    self[bg].hide()
                    self[px].hide()
                    self[lbl].hide()

    def _switch_tab(self):
        self.tab = 1 - self.tab
        self._filter()
        self._refresh()

    def do_connect(self):
        if not self.servers:
            self.session.open(MessageBox,
                "Aucune playlist.\nUtilisez SERVERS pour en ajouter.",
                MessageBox.TYPE_INFO, timeout=4)
            return
        if not (0 <= self.sel < len(self.servers)):
            return
        s    = self.servers[self.sel]
        name = s.get("name")
        host = s.get("host")
        for sv in self.all_srv:
            sv["active"] = False
        for sv in self.all_srv:
            if sv.get("host") == host and sv.get("name") == name:
                sv["active"] = True
        if self._save():
            self._load()
            self._refresh()
            self.session.open(MessageBox,
                "Activate [%s] :\n%s" % (self.TABS[self.tab], name),
                MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, "Erreur sauvegarde", MessageBox.TYPE_ERROR, timeout=3)

    def _tp(self):
        return max(1, (len(self.servers) + self.PER_PAGE - 1) // self.PER_PAGE)

    def keyUp(self):
        new = self.sel - self.GRID_COLS
        if new >= 0:
            self.sel  = new
            self.page = self.sel // self.PER_PAGE
            self._refresh()

    def keyDown(self):
        new = self.sel + self.GRID_COLS
        if new < len(self.servers):
            self.sel  = new
            self.page = self.sel // self.PER_PAGE
            self._refresh()

    def keyLeft(self):
        if self.sel % self.GRID_COLS > 0:
            self.sel -= 1
            self.page = self.sel // self.PER_PAGE
            self._refresh()
        elif self.page > 0:
            self.page -= 1
            last = min(self.page*self.PER_PAGE + self.PER_PAGE - 1, len(self.servers)-1)
            self.sel = last
            self._refresh()

    def keyRight(self):
        if self.sel % self.GRID_COLS < self.GRID_COLS - 1 and self.sel+1 < len(self.servers):
            self.sel += 1
            self.page = self.sel // self.PER_PAGE
            self._refresh()
        elif self.page + 1 < self._tp():
            self.page += 1
            self.sel   = self.page * self.PER_PAGE
            self._refresh()

    def close(self):
        super().close()
