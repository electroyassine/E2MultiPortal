#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2MultiPortal - API MAG / Stalker Portal
Detection automatique du bon chemin (stalker_portal ou chemin direct).
"""
import json, ssl, time, urllib.request, urllib.parse
from datetime import datetime

class MagAPI:
    TTL = 3600

    @staticmethod
    def _format_expiration(raw):
        """Normalise expire_billing_date (timestamp, date string, 0/'' = illimite)."""
        if raw is None:
            return ""
        s = str(raw).strip()
        if not s or s in ("0", "0000-00-00 00:00:00", "never", "Never"):
            return "Illimite"
        # Timestamp unix ?
        if s.isdigit():
            try:
                return datetime.fromtimestamp(int(s)).strftime("%d/%m/%Y")
            except Exception:
                return s
        # Chaine de date "YYYY-MM-DD ..." ou "YYYY-MM-DD"
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(s[:19], fmt).strftime("%d/%m/%Y")
            except Exception:
                continue
        return s

    # Chemins possibles pour load.php (testés dans l'ordre)
    LOAD_PATHS = [
        '/stalker_portal/server/load.php',
        '/server/load.php',
        '/portal/server/load.php',
        '/mag/server/load.php',
    ]

    def __init__(self, host, mac):
        self._raw_host   = host.strip()
        self.mac         = mac.strip().upper()
        self._token      = None
        self._token_time = 0
        self._base       = None   # URL de base détectée (sans load.php)
        self._load_url   = None   # URL complète load.php fonctionnelle

        # Nettoyer le host : retirer les suffixes connus
        h = self._raw_host.rstrip('/')
        for suffix in ['/stalker_portal/server/load.php', '/server/load.php',
                       '/stalker_portal/c', '/stalker_portal', '/portal/server/load.php',
                       '/c']:
            if h.endswith(suffix):
                h = h[:-len(suffix)]
                break
        self._base = h.rstrip('/')

    # ── URLs ─────────────────────────────────────────────────────────────────
    def _server_url(self):
        """Retourne l'URL load.php détectée ou la première par défaut."""
        if self._load_url:
            return self._load_url
        return self._base + self.LOAD_PATHS[0]

    def _referer(self):
        return self._base + '/stalker_portal/c/'

    # ── Headers ───────────────────────────────────────────────────────────────
    def _headers(self, token=None):
        mac_enc = urllib.parse.quote(self.mac)
        h = {
            'User-Agent':    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
                             '(KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
            'Accept':        '*/*',
            'Accept-Language': 'en,en-US;q=0.8',
            'X-User-Agent':  'Model: MAG250; Link: WiFi',
            'Cookie':        'mac=%s; stb_lang=en; timezone=Europe/Paris' % mac_enc,
            'Referer':       self._referer(),
        }
        if token:
            h['Authorization'] = 'Bearer %s' % token
            h['Cookie'] += '; token=%s' % token
        return h

    # ── HTTP ──────────────────────────────────────────────────────────────────
    def _get(self, url, token=None, timeout=15):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers=self._headers(token))
            with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
                raw = r.read().decode('utf-8', errors='ignore')
                return json.loads(raw)
        except Exception as e:
            print('[MagAPI] GET %s => %s' % (url, e))
            return None

    # ── Token : détection automatique du bon chemin ────────────────────────
    def get_token(self, force=False):
        now = time.time()
        if not force and self._token and (now - self._token_time) < self.TTL:
            return self._token

        # Essayer chaque chemin possible
        for path in self.LOAD_PATHS:
            load_url = self._base + path
            token = self._try_handshake(load_url)
            if token:
                self._load_url   = load_url   # mémoriser le bon chemin
                self._token      = token
                self._token_time = now
                print('[MagAPI] Token OK via %s' % load_url)
                return token

        # Tentative via portal.php
        token = self._handshake_portal()
        if token:
            self._token      = token
            self._token_time = now
            return token

        print('[MagAPI] Token introuvable pour %s' % self._base)
        return None

    def _try_handshake(self, load_url):
        """Tente handshake sur un load_url précis."""
        # v1 : avec JsHttpRequest
        url = load_url + '?type=stb&action=handshake&prehash=0&token=&JsHttpRequest=1-xml'
        token = self._extract_token(self._get(url))
        if token:
            return token
        # v2 : sans JsHttpRequest
        url2 = load_url + '?type=stb&action=handshake&prehash=0&token='
        return self._extract_token(self._get(url2))

    def _handshake_portal(self):
        """Tentative via portal.php."""
        url = self._base + '/stalker_portal/portal.php?type=stb&action=handshake&prehash=0'
        return self._extract_token(self._get(url))

    def _extract_token(self, data):
        if not data or not isinstance(data, dict):
            return None
        js = data.get('js') or data.get('data') or {}
        if isinstance(js, dict):
            return js.get('token') or js.get('random') or None
        if isinstance(js, str) and len(js) > 4:
            return js
        return None

    # ── Test connexion ────────────────────────────────────────────────────────
    EXP_FIELDS = (
        'expire_billing_date', 'tariff_expired_date', 'end_date',
        'expire_date', 'expired_date',
    )

    @classmethod
    def _find_expiration_raw(cls, js):
        """Cherche une date d'expiration parmi plusieurs noms de champs
        possibles selon la variante du portail Stalker/Ministra."""
        if not isinstance(js, dict):
            return ''
        for key in cls.EXP_FIELDS:
            v = js.get(key)
            if v not in (None, '', '0', 0, '0000-00-00 00:00:00'):
                return v
        return ''

    def test_connection(self):
        try:
            token = self.get_token(force=True)
            if not token:
                return {'success': False,
                        'message': 'Token introuvable — vérifiez Host et MAC'}
            url  = self._server_url() + '?type=stb&action=get_profile&JsHttpRequest=1-xml'
            data = self._get(url, token)
            if data and isinstance(data, dict):
                js = data.get('js', {})
                if isinstance(js, dict):
                    exp_raw = self._find_expiration_raw(js)

                    # Fallback : certains portails exposent la date
                    # d'expiration via type=account_info plutot que get_profile
                    if not exp_raw:
                        try:
                            url2  = self._server_url() + '?type=account_info&action=get_main_info&JsHttpRequest=1-xml'
                            data2 = self._get(url2, token)
                            js2 = data2.get('js', {}) if isinstance(data2, dict) else {}
                            exp_raw = self._find_expiration_raw(js2)
                        except Exception:
                            pass

                    return {
                        'success': True,
                        'mac':     self.mac,
                        'status':  'active',
                        'serial':  js.get('serial_number', 'N/A'),
                        'firmware': js.get('stb_type', 'MAG'),
                        'expiration': self._format_expiration(exp_raw),
                        'expiration_raw': exp_raw,
                        'message': 'MAG OK — token: %s...' % token[:8],
                        'load_url': self._load_url or 'N/A',
                    }
            return {'success': True, 'mac': self.mac,
                    'message': 'MAG accessible (token: %s...)' % token[:8]}
        except Exception as e:
            return {'success': False, 'message': str(e)[:120]}

    # ── Données ────────────────────────────────────────────────────────────────
    def get_genres(self, ctype='itv'):
        """Recupere les genres/categories pour un type de contenu donne.
        Plusieurs portails Stalker/Ministra utilisent des conventions
        differentes pour cet appel ; on essaie plusieurs variantes et on
        retient la premiere qui renvoie une liste non vide."""
        token = self.get_token()
        if not token:
            return []

        variants = []
        if ctype == 'itv':
            # Convention la plus courante pour les chaines live
            variants.append('type=itv&action=get_genres&JsHttpRequest=1-xml')
        # Conventions generiques (vod/series + ancien fallback itv)
        variants.append('type=stb&action=get_genres&content_type=%s&JsHttpRequest=1-xml' % ctype)
        variants.append('type=%s&action=get_genres&JsHttpRequest=1-xml' % ctype)
        variants.append('type=%s&action=get_categories&JsHttpRequest=1-xml' % ctype)

        for params in variants:
            url = self._server_url() + '?' + params
            d   = self._get(url, token)
            if not (d and isinstance(d, dict)):
                continue
            js = d.get('js', [])
            if isinstance(js, dict):
                js = js.get('data', [])
            if isinstance(js, list) and js:
                return js
        return []

    def get_channels(self, genre_id=None, page=1):
        token = self.get_token()
        if not token:
            return []
        params = 'type=itv&action=get_ordered_list&p=%d&JsHttpRequest=1-xml' % page
        if genre_id:
            params += '&genre=%s' % urllib.parse.quote(str(genre_id))
        url = self._server_url() + '?' + params
        d   = self._get(url, token)
        if d and isinstance(d, dict):
            js = d.get('js', {})
            if isinstance(js, dict):
                return js.get('data', [])
            if isinstance(js, list):
                return js
        return []

    def get_stream_url(self, cmd):
        token = self.get_token()
        if not token:
            return None
        params = urllib.parse.urlencode({
            'cmd': cmd, 'series': 0,
            'forced_storage': 'undefined',
            'disable_ad': 0, 'download': 0,
            'force_ch_link_check': 0,
            'JsHttpRequest': '1-xml',
        })
        url = self._server_url() + '?type=itv&action=create_link&' + params
        d   = self._get(url, token)
        if d and isinstance(d, dict):
            js = d.get('js', {})
            if isinstance(js, dict):
                cmd_url = js.get('cmd', '')
                if cmd_url.startswith('ffrt '):
                    cmd_url = cmd_url[5:]
                return cmd_url or None
        return None
