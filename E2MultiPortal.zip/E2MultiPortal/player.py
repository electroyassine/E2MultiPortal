#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
PlayerScreen - Ecran transparent de lecture
Reste dans la pile Enigma2 pendant la lecture.
UP/DOWN -> revenir à la liste (show parent)
EXIT/CANCEL -> revenir à la liste
"""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eServiceReference, eTimer

class PlayerScreen(Screen):
    """
    Ecran de lecture minimal et transparent.
    Le flux joue derrière. Les touches UP/DOWN/EXIT ferment
    cet écran et réaffichent l'écran parent (liste).
    """

    skin = """
<screen name="PlayerScreen" position="0,0" size="1920,1080"
        flags="wfNoBorder" backgroundColor="transparent" zPosition="0">
    <widget name="channel_name" position="40,40" size="900,60"
            font="Bold;42" foregroundColor="#ffffff" transparent="1"
            backgroundColor="transparent"/>
    <widget name="hint" position="40,1020" size="700,40"
            font="Regular;28" foregroundColor="#aaaaaa" transparent="1"
            backgroundColor="transparent"/>
</screen>"""

    def __init__(self, session, url, name, parent_screen):
        Screen.__init__(self, session)
        self.parent_screen  = parent_screen
        self.stream_url     = url
        self.stream_name    = name

        self["channel_name"] = Label(name)
        self["hint"]         = Label("UP/DOWN = liste  |  EXIT = retour")

        # Timer pour cacher le texte après 4 s
        self._hide_timer = eTimer()
        self._hide_timer.callback.append(self._hide_osd)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up":     self._back_to_list,
                "down":   self._back_to_list,
                "cancel": self._back_to_list,
                "red":    self._back_to_list,
                "ok":     self._toggle_osd,
            }, -1
        )
        self.onLayoutFinish.append(self._start_play)

    def _start_play(self):
        try:
            from .server_manager import get_player_service_type
            stype = get_player_service_type()
            sref = eServiceReference(stype, 0, self.stream_url)
            sref.setName(self.stream_name)
            self.session.nav.playService(sref)
            # Cacher le texte après 4 s
            self._hide_timer.start(4000, True)
        except Exception as e:
            self["channel_name"].setText("Erreur: %s" % str(e)[:60])

    def _hide_osd(self):
        self["channel_name"].hide()
        self["hint"].hide()

    def _toggle_osd(self):
        try:
            self["channel_name"].show()
            self["hint"].show()
            self._hide_timer.stop()
            self._hide_timer.start(4000, True)
        except Exception:
            pass

    def _back_to_list(self):
        """Ferme cet écran et réaffiche le parent. Le flux continue de
        jouer en arrière-plan (il sera remplacé/arrete par la prochaine
        lecture, ou par EXIT depuis l'ecran de liste)."""
        self._hide_timer.stop()
        self.close()
        # Le parent réapparaît automatiquement (pile Enigma2)
