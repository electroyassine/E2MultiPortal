#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Server Manager for E2MultiPortal Plugin
Gestionnaire unifié des serveurs MAG (Stalker) et Xtream Codes
"""

import json
import os
import re
import ssl
import urllib.request
import urllib.parse
import uuid
from datetime import datetime

CONFIG_FILE = "/etc/enigma2/E2MultiPortal/servers.json"


class ServerManager:
    """Gestionnaire unifié des serveurs MAG et Xtream"""

    def __init__(self, config_path=None):
        if config_path is None:
            self.config_dir = "/etc/enigma2/E2MultiPortal/"
            self.config_file_name = "servers.json"
            self.config_path = os.path.join(self.config_dir, self.config_file_name)
        else:
            self.config_path = config_path
            self.config_dir = os.path.dirname(config_path)

        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir, exist_ok=True)

        self.servers = []
        self.active_server = None
        self.load_config()

    def load_config(self):
        """Charge la configuration"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                if isinstance(data, list):
                    self.servers = data
                elif isinstance(data, dict) and "servers" in data:
                    self.servers = data["servers"]
                else:
                    self.servers = []

                for i, server in enumerate(self.servers):
                    self._normalize_server(server)
                    print(f"[E2MultiPortal] Serveur {i}: {server.get('name')} - Type: {server.get('type')} - Host: {server.get('host')}")

                for server in self.servers:
                    if server.get("active", False):
                        self.active_server = server
                        print(f"[E2MultiPortal] Serveur actif: {server.get('name')}")
                        break

                return True
            else:
                self.servers = []
                self.save_config()
                return True

        except Exception as e:
            print(f"[E2MultiPortal] Erreur chargement: {e}")
            self.servers = []
            return False

    def save_config(self):
        """Sauvegarde la configuration"""
        try:
            data = {
                "servers": self.servers,
                "metadata": {
                    "last_modified": datetime.now().isoformat(),
                    "total_servers": len(self.servers),
                    "version": "1.0"
                }
            }

            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            print(f"[E2MultiPortal] Configuration sauvegardée: {len(self.servers)} serveurs")
            return True

        except Exception as e:
            print(f"[E2MultiPortal] Erreur sauvegarde: {e}")
            return False

    def _normalize_server(self, server):
        """Normalise les données d'un serveur"""
        if "id" not in server:
            server["id"] = str(uuid.uuid4())[:8]

        if "type" not in server:
            server["type"] = "mag"

        if "name" not in server:
            server["name"] = "Serveur sans nom"

        if "host" not in server or not server["host"]:
            server["host"] = ""

        if server["type"] == "mag":
            if "mac" not in server:
                server["mac"] = "00:1A:79:00:00:00"
            else:
                server["mac"] = self.format_mac_address(server["mac"])
        else:  # xtream
            if "username" not in server:
                server["username"] = server.get("user", "")
            if "password" not in server:
                server["password"] = ""
            if "port" not in server:
                server["port"] = 80

        if "active" not in server:
            server["active"] = False

    def get_servers(self, server_type=None):
        """Retourne la liste des serveurs"""
        if server_type and server_type != 'all':
            return [s for s in self.servers if s.get("type") == server_type]
        return self.servers

    def get_active_server(self):
        """Retourne le serveur actif"""
        for server in self.servers:
            if server.get("active", False):
                return server
        return None

    def add_server(self, **kwargs):
        """Ajoute un nouveau serveur"""
        server_type = kwargs.get("server_type", "mag")
        name = kwargs.get("name", "").strip()
        host = kwargs.get("host", "").strip()

        if not name:
            return {'success': False, 'message': "Le nom est requis"}
        if not host:
            return {'success': False, 'message': "L'URL du serveur est requise"}

        for server in self.servers:
            if server["name"] == name:
                return {'success': False, 'message': f"Le serveur '{name}' existe déjà"}

        new_server = {
            "id": str(uuid.uuid4())[:8],
            "type": server_type,
            "name": name,
            "host": host,
            "active": False
        }

        if kwargs.get("expiration"):
            new_server["expiration"] = kwargs["expiration"]

        if server_type == "mag":
            mac = kwargs.get("mac", "00:1A:79:00:00:00")
            new_server["mac"] = self.format_mac_address(mac)
        else:  # xtream
            new_server["username"] = kwargs.get("username", "").strip()
            new_server["password"] = kwargs.get("password", "").strip()
            new_server["port"] = int(kwargs.get("port", 80))

            if not new_server["username"]:
                return {'success': False, 'message': "Nom d'utilisateur requis pour Xtream"}
            if not new_server["password"]:
                return {'success': False, 'message': "Mot de passe requis pour Xtream"}

        self.servers.insert(0, new_server)

        if len(self.servers) == 1:
            new_server["active"] = True
            self.active_server = new_server

        if self.save_config():
            return {'success': True, 'message': f"Serveur '{name}' ajouté avec succès!", 'server': new_server}
        else:
            self.servers.pop(0)
            return {'success': False, 'message': "Erreur sauvegarde"}

    def update_server(self, index, **kwargs):
        """Met à jour un serveur"""
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}

        server = self.servers[index]

        if "name" in kwargs and kwargs["name"]:
            server["name"] = kwargs["name"].strip()

        if "host" in kwargs and kwargs["host"]:
            server["host"] = kwargs["host"].strip()

        if server["type"] == "mag" and "mac" in kwargs:
            server["mac"] = self.format_mac_address(kwargs["mac"])

        if server["type"] == "xtream":
            if "username" in kwargs and kwargs["username"]:
                server["username"] = kwargs["username"].strip()
            if "password" in kwargs and kwargs["password"]:
                server["password"] = kwargs["password"].strip()
            if "port" in kwargs:
                server["port"] = int(kwargs["port"])

        if "expiration" in kwargs and kwargs["expiration"]:
            server["expiration"] = kwargs["expiration"]

        if "active" in kwargs:
            server["active"] = kwargs["active"]
            if server["active"]:
                for s in self.servers:
                    if s != server:
                        s["active"] = False
                self.active_server = server

        if self.save_config():
            return {'success': True, 'message': "Serveur mis à jour"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}

    def delete_server(self, index):
        """Supprime un serveur"""
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}

        server = self.servers[index]
        server_name = server["name"]
        was_active = server["active"]

        del self.servers[index]

        if was_active and self.servers:
            self.servers[0]["active"] = True
            self.active_server = self.servers[0]
        elif was_active:
            self.active_server = None

        if self.save_config():
            return {'success': True, 'message': f"Serveur '{server_name}' supprimé"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}

    def format_mac_address(self, mac):
        """Formate une adresse MAC"""
        if not mac:
            return "00:00:00:00:00:00"

        mac = mac.strip().upper()
        mac = re.sub(r'[^0-9A-F]', '', mac)

        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]

        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])

    def validate_mac_address(self, mac):
        """Valide une adresse MAC"""
        pattern = r'^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$'
        return bool(re.match(pattern, mac))


# ─── Standalone functions used by webserver.py ───────────────────────────────

_manager = None


def _get_manager():
    global _manager
    if _manager is None:
        _manager = ServerManager()
    return _manager


def get_servers(server_type=None):
    return _get_manager().get_servers(server_type)


def get_active_server():
    return _get_manager().get_active_server()


def add_server(data):
    mgr = _get_manager()
    st = data.get("type", "mag")
    return mgr.add_server(
        server_type=st,
        name=data.get("name", ""),
        host=data.get("host", ""),
        mac=data.get("mac", ""),
        username=data.get("username", ""),
        password=data.get("password", ""),
        port=data.get("port", 80),
        expiration=data.get("expiration", ""),
    )


def update_server(server_id, data):
    mgr = _get_manager()
    idx = next((i for i, s in enumerate(mgr.servers) if s.get("id") == server_id), None)
    if idx is None:
        return {'success': False, 'message': "Serveur non trouvé"}
    return mgr.update_server(idx, **data)


def delete_server(server_id):
    mgr = _get_manager()
    idx = next((i for i, s in enumerate(mgr.servers) if s.get("id") == server_id), None)
    if idx is None:
        return {'success': False, 'message': "Serveur non trouvé"}
    return mgr.delete_server(idx)


def set_active_server(server_id):
    mgr = _get_manager()
    idx = next((i for i, s in enumerate(mgr.servers) if s.get("id") == server_id), None)
    if idx is None:
        return {'success': False, 'message': "Serveur non trouvé"}
    return mgr.update_server(idx, active=True)


def get_stats():
    mgr = _get_manager()
    xtream = [s for s in mgr.servers if s.get("type") == "xtream"]
    mag = [s for s in mgr.servers if s.get("type") == "mag"]
    active = mgr.get_active_server()
    return {
        "xtream": {"total": len(xtream), "servers": xtream},
        "mag": {"total": len(mag), "servers": mag},
        "active": active
    }


def format_mac(mac):
    return ServerManager().format_mac_address(mac)


# ══════════════════════════════════════════════════════════════════════════
#  Préférence du lecteur (player engine)
# ══════════════════════════════════════════════════════════════════════════

SETTINGS_FILE = "/etc/enigma2/E2MultiPortal/settings.json"

# id interne -> (libelle, type de service Enigma2 pour eServiceReference)
PLAYER_ENGINES = {
    "gstreamer":   ("GStreamer",   4097),
    "exteplayer3": ("ExtEplayer3", 5001),
    "gstplayer":   ("GstPlayer",   8193),
}
PLAYER_ORDER = ["gstreamer", "exteplayer3", "gstplayer"]
DEFAULT_PLAYER = "gstreamer"


def _load_settings():
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE) as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_settings(data):
    try:
        os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
        with open(SETTINGS_FILE, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


def get_player_engine():
    """Retourne l'id interne du lecteur choisi (gstreamer/exteplayer3/gstplayer)."""
    data = _load_settings()
    pid = data.get("player", DEFAULT_PLAYER)
    return pid if pid in PLAYER_ENGINES else DEFAULT_PLAYER


def get_player_service_type():
    """Retourne le type de service Enigma2 (int) pour eServiceReference."""
    pid = get_player_engine()
    return PLAYER_ENGINES[pid][1]


def get_player_label():
    """Retourne le libelle lisible du lecteur choisi."""
    pid = get_player_engine()
    return PLAYER_ENGINES[pid][0]


def set_player_engine(player_id):
    if player_id not in PLAYER_ENGINES:
        return {"success": False, "message": "Lecteur inconnu"}
    data = _load_settings()
    data["player"] = player_id
    if _save_settings(data):
        return {"success": True, "player": player_id, "label": PLAYER_ENGINES[player_id][0]}
    return {"success": False, "message": "Erreur sauvegarde"}
