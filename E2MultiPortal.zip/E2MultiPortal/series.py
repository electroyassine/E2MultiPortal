#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
SeriesScreen - Mode liste classique 4 colonnes
Categories | Series | Saisons | Episodes
Droite: poster + infos + bouton LIRE
"""
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from enigma import eTimer
import json, os, ssl, urllib.request, urllib.parse, threading

CONFIG_FILE = "/etc/enigma2/E2MultiPortal/servers.json"
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"

class SeriesScreen(Screen):

    skin = """
<screen name="SeriesScreen" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#06050f">
    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/vod.png" zPosition="-1"/>

    <widget name="title"       position="0,8"  size="1920,46"
            font="Bold;38" halign="center" foregroundColor="#ffffff" transparent="1"/>
    <widget name="server_info" position="0,54" size="1920,26"
            font="Regular;20" halign="center" foregroundColor="#bbbbbb" transparent="1"/>

    <!-- COL 1: Categories x=20 w=250 -->
    <widget name="lbl_cat"   position="20,84"  size="250,32"
            font="Bold;20" halign="center" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="cat_list"  position="20,120" size="250,900"
            font="Regular;19" itemHeight="34"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>
    <eLabel position="272,84" size="2,936" backgroundColor="#2a2a5a" zPosition="2"/>

    <!-- COL 2: Series x=280 w=280 -->
    <widget name="lbl_ser"   position="280,84"  size="280,32"
            font="Bold;20" halign="center" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="ser_list"  position="280,120" size="280,900"
            font="Regular;19" itemHeight="34"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>
    <eLabel position="562,84" size="2,936" backgroundColor="#2a2a5a" zPosition="2"/>

    <!-- COL 3: Saisons x=568 w=200 -->
    <widget name="lbl_sai"   position="568,84"  size="200,32"
            font="Bold;20" halign="center" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="sai_list"  position="568,120" size="200,900"
            font="Regular;19" itemHeight="34"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>
    <eLabel position="770,84" size="2,936" backgroundColor="#2a2a5a" zPosition="2"/>

    <!-- COL 4: Episodes x=776 w=280 -->
    <widget name="lbl_ep"    position="776,84"  size="280,32"
            font="Bold;20" halign="center" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="ep_list"   position="776,120" size="280,900"
            font="Regular;19" itemHeight="34"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>
    <eLabel position="1058,84" size="2,936" backgroundColor="#2a2a5a" zPosition="2"/>

    <!-- COL 5: Poster + infos x=1068 w=834 -->
    <eLabel position="1068,84" size="834,936" backgroundColor="#b49e86" zPosition="1"/>

    <widget name="poster"    position="1082,100" size="260,380"
            zPosition="3" transparent="1" alphatest="on" scale="1"/>
    <widget name="poster_bg" position="1082,100" size="260,380"
            backgroundColor="#b49e86" transparent="0" zPosition="2"/>

    <widget name="info_title"  position="1360,105" size="530,60"
            font="Bold;34" foregroundColor="#ffff00" transparent="1" zPosition="3"/>
    <widget name="info_year"   position="1360,172" size="260,28"
            font="Regular;22" foregroundColor="#2a2014" transparent="1" zPosition="3"/>
    <widget name="info_rating" position="1620,172" size="270,28"
            font="Bold;24" halign="right" foregroundColor="#f39c12" transparent="1" zPosition="3"/>
    <widget name="info_genre"  position="1360,206" size="530,26"
            font="Regular;20" foregroundColor="#2a2014" transparent="1" zPosition="3"/>
    <widget name="info_desc"   position="1360,238" size="530,242"
            font="Regular;20" foregroundColor="#2a2014" transparent="1" zPosition="3"/>

    <eLabel position="1082,494" size="806,2" backgroundColor="#2a2a5a" zPosition="3"/>
    <widget name="btn_play" position="1182,512" size="300,56"
            font="Bold;32" halign="center" valign="center"
            backgroundColor="#1a6e34" foregroundColor="#ffffff" zPosition="3"/>
    <widget name="btn_search" position="1182,576" size="300,50"
            font="Bold;26" halign="center" valign="center"
            backgroundColor="#2980b9" foregroundColor="#ffffff" zPosition="3"/>
    <widget name="hint" position="1082,634" size="806,28"
            font="Regular;20" halign="center" foregroundColor="#446644" transparent="1" zPosition="3"/>

    <widget name="status" position="20,1042" size="1880,30"
            font="Regular;20" halign="center" foregroundColor="#004422" transparent="1" zPosition="3"/>
</screen>""" % PLUGIN_PATH

    def __init__(self, session):
        Screen.__init__(self, session)
        from . import poster_manager as PM
        self._PM = PM

        self["title"]       = Label("Series TV")
        self["server_info"] = Label("")
        self["lbl_cat"]     = Label("CATEGORIES")
        self["lbl_ser"]     = Label("SERIES")
        self["lbl_sai"]     = Label("SAISONS")
        self["lbl_ep"]      = Label("EPISODES")
        self["status"]      = Label("")
        self["cat_list"]    = MenuList([], enableWrapAround=True)
        self["ser_list"]    = MenuList([], enableWrapAround=True)
        self["sai_list"]    = MenuList([], enableWrapAround=True)
        self["ep_list"]     = MenuList([], enableWrapAround=True)
        self["poster"]      = Pixmap()
        self["poster_bg"]   = Label("")
        self["info_title"]  = Label("")
        self["info_year"]   = Label("")
        self["info_rating"] = Label("")
        self["info_genre"]  = Label("")
        self["info_desc"]   = Label("")
        self["btn_play"]    = Label("  ▶  LIRE")
        self["btn_search"]  = Label("  \U0001F50D  RECHERCHE")
        self["hint"]        = Label("Vert=Lire  Bleu=Recherche  EXIT=retour")

        self.categories  = []
        self.series_data = []
        self.seasons     = []
        self.episodes    = []
        self.focus       = "cat"   # cat | ser | sai | ep
        self.srv_type    = None
        self.base_url    = None
        self.username    = None
        self.password    = None
        self._mag_srv    = None
        self._mag_api    = None

        self._info_timer = eTimer()
        self._info_timer.callback.append(self._load_serie_info)

        self["actions"] = ActionMap(
            ["DirectionActions","OkCancelActions","ColorActions","MenuActions"],
            {
                "up":     self.keyUp,
                "down":   self.keyDown,
                "left":   self.keyLeft,
                "right":  self.keyRight,
                "ok":     self.keyOk,
                "cancel": self.keyBack,
                "red":    self.keyBack,
                "green":  self.keyPlay,
                "blue":   self.do_search,
                "menu":   self.keyRefresh,
            }, -1
        )
        self.onLayoutFinish.append(self._start)

    # ── Init ──────────────────────────────────────────────────────────────────
    def _start(self):
        self._clear_right()
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            for s in data.get("servers",[]):
                if not s.get("active"): continue
                st = s.get("type","mag")
                self["server_info"].setText("%s (%s)"%(s.get("name",""),st.upper()))
                if st == "xtream":
                    self.srv_type="xtream"
                    self.base_url=s.get("host","").rstrip("/")
                    self.username=s.get("username","")
                    self.password=s.get("password","")
                    threading.Thread(target=self._load_xtream_cats,daemon=True).start()
                elif st in ("mag","stalker"):
                    self.srv_type="mag"; self._mag_srv=s
                    threading.Thread(target=self._load_mag_cats,daemon=True).start()
                return
            self["status"].setText("Aucun serveur actif")
        except Exception as e:
            self["status"].setText("Erreur: %s"%str(e)[:50])

    # ── Recherche ─────────────────────────────────────────────────────────────
    def do_search(self):
        self.session.openWithCallback(
            self._search_done, VirtualKeyBoard,
            title="Rechercher une serie (nom ou partie du nom)", text="")

    def _search_done(self, text):
        if not text:
            return
        text = text.strip()
        if not text:
            return
        self["status"].setText("Recherche...")
        threading.Thread(target=self._perform_search, args=(text,), daemon=True).start()

    def _perform_search(self, query):
        try:
            # Recharge (ou recupere du cache) la liste complete "Toutes"
            if self.srv_type == "xtream":
                self._load_xtream_series("")
            else:
                self._load_mag_series("")

            q = query.strip().lower()
            results = [s for s in self.series_data if q in (s.get("name","") or "").lower()]

            self.series_data = results
            self["ser_list"].setList([s["name"] for s in self.series_data])
            self["lbl_ser"].setText("Recherche : '%s'  (%d resultat%s)" % (
                query, len(results), "s" if len(results) != 1 else ""))
            self["sai_list"].setList([]); self["ep_list"].setList([])
            self.seasons=[]; self.episodes=[]
            self["lbl_sai"].setText("SAISONS"); self["lbl_ep"].setText("EPISODES")
            self["status"].setText("")
            self.focus="ser"
            self._info_timer.stop(); self._info_timer.start(300,True)
        except Exception as e:
            self["status"].setText("Erreur recherche: %s" % str(e)[:60])

    def keyRefresh(self):
        """Rafraichissement manuel (touche MENU) : relance le chargement,
        ce qui retente le serveur et met a jour le cache en cas de succes."""
        self["status"].setText("Rafraichissement...")
        self["cat_list"].setList([]); self["ser_list"].setList([])
        self["sai_list"].setList([]); self["ep_list"].setList([])
        self.categories=[]; self.series_data=[]; self.seasons=[]; self.episodes=[]
        threading.Thread(target=self._start, daemon=True).start()

    def _clear_right(self):
        for w in ("info_title","info_year","info_rating","info_genre","info_desc"):
            self[w].setText("")
        try: self["poster"].hide()
        except: pass

    def _xurl(self, action, extra=""):
        return "%s/player_api.php?username=%s&password=%s&action=%s%s"%(
            self.base_url,self.username,self.password,action,extra)

    def _fetch(self, url, timeout=20):
        try:
            ctx=ssl._create_unverified_context()
            req=urllib.request.Request(url,headers={"User-Agent":"E2MultiPortal/1.0"})
            with urllib.request.urlopen(req,context=ctx,timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","ignore"))
        except Exception as e:
            print("[Series] %s"%e); return None

    # ── Xtream ────────────────────────────────────────────────────────────────
    def _load_xtream_cats(self):
        self["status"].setText("Chargement categories...")
        from . import cache_manager as CM
        cache_key = "series_cats_%s_%s" % (self.base_url, self.username)

        def fetch():
            d = self._fetch(self._xurl("get_series_categories"))
            out = []
            for c in (d or []):
                if isinstance(c,dict):
                    out.append({"id":c.get("category_id",""),"name":c.get("category_name","?")})
            return out

        raw, from_cache = CM.get_or_fetch(cache_key, fetch)
        self.categories=[{"id":"","name":"Toutes"}] + (raw or [])
        self["cat_list"].setList([c["name"] for c in self.categories])
        self["lbl_cat"].setText("CATEGORIES (%d)"%len(self.categories))
        self["status"].setText("Categories (cache)" if from_cache else ""); self.focus="cat"

    def _load_xtream_series(self, cat_id):
        self["status"].setText("Chargement series...")
        from . import cache_manager as CM
        cache_key = "series_list_%s_%s_%s" % (self.base_url, self.username, cat_id or "all")
        extra=("&category_id=%s"%cat_id) if cat_id else ""

        def fetch():
            d = self._fetch(self._xurl("get_series",extra)) or []
            out = []
            for s in d:
                if isinstance(s,dict):
                    out.append({
                        "id":s.get("series_id",""),"name":s.get("name","?"),
                        "cover":s.get("cover","") or s.get("stream_icon",""),
                        "rating":s.get("rating",""),"genre":s.get("genre",""),
                        "plot":s.get("plot",""),"year":s.get("year","")})
            return out

        self.series_data, from_cache = CM.get_or_fetch(cache_key, fetch)
        self.series_data = self.series_data or []
        self["ser_list"].setList([s["name"] for s in self.series_data])
        self["lbl_ser"].setText("SERIES (%d)"%len(self.series_data))
        self["sai_list"].setList([]); self["ep_list"].setList([])
        self.seasons=[]; self.episodes=[]
        self["lbl_sai"].setText("SAISONS"); self["lbl_ep"].setText("EPISODES")
        self["status"].setText("Series (cache)" if from_cache else ""); self.focus="ser"
        self._info_timer.stop(); self._info_timer.start(300,True)

    def _load_xtream_seasons(self, serie):
        self["status"].setText("Chargement saisons...")
        d=self._fetch(self._xurl("get_series_info","&series_id=%s"%serie["id"])) or {}
        seasons=d.get("seasons",[]); eps_map=d.get("episodes",{}); info=d.get("info",{})
        if info:
            for k,v in (("cover","cover"),("plot","plot"),("rating","rating")):
                if info.get(v): serie[k]=info[v]
            if info.get("releaseDate"): serie["year"]=info["releaseDate"][:4]
            self._load_serie_info()
        if seasons:
            self.seasons=[{"id":str(s.get("season_number","")),"name":"Saison %s"%s.get("season_number","?"),
                           "eps":eps_map.get(str(s.get("season_number")),[])} for s in seasons]
        else:
            self.seasons=[{"id":k,"name":"Saison %s"%k,"eps":v}
                          for k,v in sorted(eps_map.items(),key=lambda x:int(x[0]) if x[0].isdigit() else 0)]
        self["sai_list"].setList([s["name"] for s in self.seasons])
        self["lbl_sai"].setText("SAISONS (%d)"%len(self.seasons))
        self["ep_list"].setList([]); self.episodes=[]
        self["lbl_ep"].setText("EPISODES"); self["status"].setText("")
        self.focus="sai"

    def _load_eps_from_season(self, idx):
        if not (0<=idx<len(self.seasons)): return
        eps=self.seasons[idx].get("eps",[])
        self.episodes=[{"id":e.get("id",""),"name":e.get("title","Ep %s"%e.get("episode_num","?")),"ext":e.get("container_extension","mp4")}
                       for e in eps if isinstance(e,dict)]
        self["ep_list"].setList(["  "+ep["name"] for ep in self.episodes])
        self["lbl_ep"].setText("EPISODES (%d)"%len(self.episodes))
        self.focus="ep"

    # ── MAG ───────────────────────────────────────────────────────────────────
    def _load_mag_cats(self):
        self["status"].setText("MAG: connexion...")
        try:
            from .api_mag import MagAPI
            srv=self._mag_srv
            self._mag_api=MagAPI(srv.get("host",""),srv.get("mac",""))
            token=self._mag_api.get_token()
            if not token: self["status"].setText("MAG: token introuvable"); return
            ctx=ssl._create_unverified_context(); cats_raw=[]
            for action in ("get_categories","get_genres"):
                try:
                    url=self._mag_api._server_url()+"?type=series&action=%s&JsHttpRequest=1-xml"%action
                    req=urllib.request.Request(url,headers=self._mag_api._headers(token))
                    with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
                        d=json.loads(r.read().decode("utf-8","ignore"))
                    js=d.get("js",[]); js=js.get("data",[]) if isinstance(js,dict) else js
                    if js: cats_raw=js; break
                except: pass
            self.categories=[{"id":"","name":"Toutes"}]
            for c in cats_raw:
                if isinstance(c,dict):
                    self.categories.append({"id":c.get("id",""),"name":c.get("title",c.get("name","?"))})
            self["cat_list"].setList([c["name"] for c in self.categories])
            self["lbl_cat"].setText("CATEGORIES (%d)"%len(self.categories))
            self["status"].setText(""); self.focus="cat"
        except Exception as e:
            self["status"].setText("MAG: %s"%str(e)[:60])

    def _load_mag_series(self, cat_id):
        self["status"].setText("MAG: chargement series...")
        try:
            token=self._mag_api.get_token(); ctx=ssl._create_unverified_context()
            params="type=series&action=get_ordered_list&movie_id=0&JsHttpRequest=1-xml"
            if cat_id: params+="&category=%s"%cat_id
            url=self._mag_api._server_url()+"?"+params
            req=urllib.request.Request(url,headers=self._mag_api._headers(token))
            with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
                d=json.loads(r.read().decode("utf-8","ignore"))
            raw=d.get("js",{}); items=raw.get("data",[]) if isinstance(raw,dict) else (raw if isinstance(raw,list) else [])
            self.series_data=[]
            for s in items:
                if not isinstance(s,dict): continue
                self.series_data.append({
                    "id":s.get("id",""),"name":s.get("name","?"),
                    "cover":s.get("screenshot_uri","") or s.get("cover",""),
                    "rating":"","genre":"","plot":"","year":"",
                    "cat_id":cat_id})
            self["ser_list"].setList([s["name"] for s in self.series_data])
            self["lbl_ser"].setText("SERIES (%d)"%len(self.series_data))
            self["sai_list"].setList([]); self["ep_list"].setList([])
            self.seasons=[]; self.episodes=[]
            self["lbl_sai"].setText("SAISONS"); self["lbl_ep"].setText("EPISODES")
            self["status"].setText(""); self.focus="ser"
            self._info_timer.stop(); self._info_timer.start(300,True)
        except Exception as e:
            self["status"].setText("MAG series: %s"%str(e)[:60])

    def _load_mag_episodes(self, serie):
        """Point d'entree quand on valide une serie MAG : recupere la
        liste des saisons via get_ordered_list(movie_id=<series_id>,
        season_id=0, episode_id=0). Convention confirmee fonctionnelle sur
        ce portail (LION/MAG) : chaque saison a un id composite
        '<series_id>:<season_num>'."""
        self["status"].setText("MAG: chargement saisons...")
        self._cur_series_ctx = serie
        try:
            items = self._fetch_mag_ordered_list(serie.get("id",""), "0", serie.get("cat_id"))
            seasons=[]
            for it in items:
                if not isinstance(it,dict): continue
                sid = str(it.get("id",""))
                num = sid.split(":")[1] if ":" in sid else "1"
                name = it.get("name") or it.get("title") or ("Saison %s"%num)
                seasons.append({"id":sid,"name":name,"num":num})
            if not seasons:
                # Repli : pas de sous-saisons, une seule saison implicite
                seasons=[{"id":"%s:1"%serie.get("id",""),"name":"Saison 1","num":"1"}]
            self.seasons=seasons
            self["sai_list"].setList([s["name"] for s in self.seasons])
            self["lbl_sai"].setText("SAISONS (%d)"%len(self.seasons))
            self["ep_list"].setList([]); self.episodes=[]
            self["lbl_ep"].setText("EPISODES")
            self.focus="sai"
            self["status"].setText("")
        except Exception as e:
            self["status"].setText("MAG saisons: %s"%str(e)[:60])

    def _fetch_mag_ordered_list(self, movie_id, season_id, cat_id):
        """Appel brut get_ordered_list (type=series). Retourne la liste
        'data' (ou [])."""
        token=self._mag_api.get_token(); ctx=ssl._create_unverified_context()
        params="type=series&action=get_ordered_list&movie_id=%s&season_id=%s&episode_id=0&JsHttpRequest=1-xml"%(movie_id,season_id)
        if cat_id: params+="&category=%s"%cat_id
        url=self._mag_api._server_url()+"?"+params
        req=urllib.request.Request(url,headers=self._mag_api._headers(token))
        with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
            d=json.loads(r.read().decode("utf-8","ignore"))
        raw=d.get("js",{})
        return raw.get("data",[]) if isinstance(raw,dict) else (raw if isinstance(raw,list) else [])

    def _load_mag_season_eps(self, season):
        """Recupere les episodes d'une saison via get_ordered_list
        (movie_id=<series_id>&season_id=<id composite de la saison>&
        episode_id=0). Le portail peut renvoyer les items de TOUTES les
        saisons dans cette reponse : on filtre sur l'id de la saison
        choisie. Chaque item correspondant fournit un 'cmd' (template) et un
        champ 'series' = liste des numeros d'episodes disponibles."""
        self["status"].setText("MAG: chargement episodes...")
        serie = getattr(self,"_cur_series_ctx",None) or self._cur_serie() or {}
        try:
            items = self._fetch_mag_ordered_list(serie.get("id",""), season.get("id",""), serie.get("cat_id"))
            matching = [it for it in items if isinstance(it,dict) and str(it.get("id",""))==str(season.get("id",""))]
            if not matching:
                matching = [it for it in items if isinstance(it,dict)]

            episodes=[]
            for it in matching:
                cmd = it.get("cmd","")
                nums = it.get("series",[])
                if isinstance(nums,list) and nums:
                    for n in nums:
                        episodes.append({"id":season.get("id",""),"ep_num":str(n),
                                          "name":"Episode %s"%n,"cmd":cmd})
                elif cmd:
                    episodes.append({"id":season.get("id",""),"ep_num":"1",
                                      "name":it.get("name") or "Episode 1","cmd":cmd})

            if not episodes:
                episodes=self._parse_mag_episodes(
                    self._fetch_mag_eps_legacy(serie.get("id",""), season.get("id","")))

            self._show_mag_episodes(episodes)
        except Exception as e:
            self["status"].setText("MAG episodes: %s"%str(e)[:60])

    @staticmethod
    def _parse_mag_episodes(items):
        """Convertit une liste brute (repli get_episodes) en episodes.
        Si le nom est absent/generique, on numerote 'Episode N'."""
        episodes=[]
        for idx,e in enumerate(items,1):
            if not isinstance(e,dict): continue
            cmd=e.get("cmd","")
            if cmd.startswith("ffmpeg "): cmd=cmd[7:].strip()
            name=(e.get("name") or e.get("title") or "").strip()
            if not name or name.lower() in ("ep","episode"):
                name="Episode %d"%idx
            episodes.append({"id":e.get("id",""),"ep_num":str(idx),"name":name,"cmd":cmd})
        return episodes

    def _show_mag_episodes(self, episodes):
        self.episodes=episodes
        self["ep_list"].setList(["  "+ep["name"] for ep in self.episodes])
        self["lbl_ep"].setText("EPISODES (%d)"%len(self.episodes))
        self.focus="ep"
        self["status"].setText("" if episodes else "MAG: aucun episode trouve pour cette saison")

    def _fetch_mag_eps_legacy(self, movie_id, season_id):
        """Repli sur les anciennes actions get_episodes (series_id/season_id),
        utilisees par certains portails plus anciens."""
        try:
            token=self._mag_api.get_token(); ctx=ssl._create_unverified_context()
            url=self._mag_api._server_url()+"?type=series&action=get_episodes&series_id=%s&season_id=%s&JsHttpRequest=1-xml"%(movie_id,season_id)
            req=urllib.request.Request(url,headers=self._mag_api._headers(token))
            with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
                d=json.loads(r.read().decode("utf-8","ignore"))
            js=d.get("js",{}); raw=js if isinstance(js,list) else js.get("data",[])
            out=[]
            for e in raw:
                if isinstance(e,dict):
                    out.append(e)
            return out
        except Exception:
            return []

    def _mag_resolve_episode_url(self, cmd, ep_num):
        """Resout l'URL de lecture d'un episode via create_link
        (type=vod, cmd=<template de la saison>, series=<numero episode>)."""
        token=self._mag_api.get_token(); ctx=ssl._create_unverified_context()
        params=urllib.parse.urlencode({
            "type":"vod","action":"create_link","cmd":cmd,"series":ep_num,
            "forced_storage":"","disable_ad":"0","download":"0",
            "force_ch_link_check":"0","JsHttpRequest":"1-xml"})
        url=self._mag_api._server_url()+"?"+params
        req=urllib.request.Request(url,headers=self._mag_api._headers(token))
        with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
            d=json.loads(r.read().decode("utf-8","ignore"))
        js=d.get("js",{})
        stream=js.get("cmd","") if isinstance(js,dict) else ""
        if stream.startswith("ffmpeg "): stream=stream[7:].strip()
        return stream or None


    # ── Info + Poster ─────────────────────────────────────────────────────────
    def _trigger_info(self):
        self._info_timer.stop()
        self._info_timer.start(400, True)

    def _cur_serie(self):
        idx = self["ser_list"].getCurrentIndex()
        if 0 <= idx < len(self.series_data): return self.series_data[idx]
        return None

    def _load_serie_info(self):
        s = self._cur_serie()
        if not s: return
        name = s.get("name","")
        self["info_title"].setText(name)
        if s.get("year"): self["info_year"].setText(s["year"])
        if s.get("rating"): self["info_rating"].setText("Note: %s"%s["rating"])
        if s.get("genre"): self["info_genre"].setText(s["genre"])
        if s.get("plot"): self["info_desc"].setText(s["plot"][:260])
        cover = self._PM.get_stream_icon(s)
        if not cover: cover = s.get("cover","")
        if cover: self._PM.load_and_show(self["poster"],cover)
        else:
            try: self["poster"].hide()
            except: pass
        # TMDB
        def on_info(info):
            self["info_title"].setText(info.get("title",name))
            if info.get("year"): self["info_year"].setText(info["year"])
            if info.get("rating"): self["info_rating"].setText("TMDB: %.1f/10"%info["rating"])
            if info.get("genre"): self["info_genre"].setText(info["genre"])
            if info.get("desc"): self["info_desc"].setText(info["desc"])
        def on_poster(url): self._PM.load_and_show(self["poster"],url)
        self._PM.fetch_tmdb_series(self._PM.clean_title(name), on_info, on_poster if not cover else lambda u:None)

    # ── Lecture ───────────────────────────────────────────────────────────────
    def keyPlay(self):
        if self.focus != "ep": return
        idx = self["ep_list"].getCurrentIndex()
        if not (0<=idx<len(self.episodes)): return
        ep = self.episodes[idx]; name = ep.get("name","Episode")
        if self.srv_type == "xtream":
            url = "%s/series/%s/%s/%s.%s"%(self.base_url,self.username,self.password,ep.get("id",""),ep.get("ext","mp4"))
            self._open_player(url,name)
        else:
            cmd = ep.get("cmd","")
            if cmd.startswith("http"):
                self._open_player(cmd,name)
            else:
                self["status"].setText("Resolution MAG...")
                ep_num = ep.get("ep_num","1")
                def resolve():
                    try:
                        r = self._mag_resolve_episode_url(cmd, ep_num)
                        if r: self._open_player(r,name)
                        else: self["status"].setText("MAG: flux introuvable")
                    except Exception as e:
                        self["status"].setText("Err: %s"%str(e)[:40])
                threading.Thread(target=resolve,daemon=True).start()

    def _open_player(self, url, name):
        try:
            from .player import PlayerScreen
            self.session.openWithCallback(lambda *r: None, PlayerScreen,
                                          url=url, name=name, parent_screen=self)
        except Exception as e:
            self["status"].setText("Erreur: %s"%str(e)[:50])

    # ── Navigation ────────────────────────────────────────────────────────────
    def keyOk(self):
        if self.focus == "cat":
            idx = self["cat_list"].getCurrentIndex()
            if 0 <= idx < len(self.categories):
                c = self.categories[idx]
                if self.srv_type == "xtream":
                    threading.Thread(target=self._load_xtream_series,args=(c["id"],),daemon=True).start()
                else:
                    threading.Thread(target=self._load_mag_series,args=(c["id"],),daemon=True).start()
        elif self.focus == "ser":
            s = self._cur_serie()
            if s:
                self._cur_serie_obj = s
                if self.srv_type == "xtream":
                    threading.Thread(target=self._load_xtream_seasons,args=(s,),daemon=True).start()
                else:
                    threading.Thread(target=self._load_mag_episodes,args=(s,),daemon=True).start()
        elif self.focus == "sai":
            idx = self["sai_list"].getCurrentIndex()
            if self.srv_type == "xtream":
                self._load_eps_from_season(idx)
            else:
                if 0<=idx<len(self.seasons):
                    s=self.seasons[idx]
                    if s.get("eps"): self._load_eps_from_season(idx)
                    else: threading.Thread(target=self._load_mag_season_eps,args=(s,),daemon=True).start()
        elif self.focus == "ep":
            self.keyPlay()

    def keyBack(self):
        if self.focus == "ep":
            self.focus = "sai"
        elif self.focus == "sai":
            self["ep_list"].setList([]); self.episodes=[]
            self["lbl_ep"].setText("EPISODES")
            self.focus = "ser"
        elif self.focus == "ser":
            self["ser_list"].setList([]); self.series_data=[]
            self["sai_list"].setList([]); self["ep_list"].setList([])
            self["lbl_ser"].setText("SERIES")
            self["lbl_sai"].setText("SAISONS"); self["lbl_ep"].setText("EPISODES")
            self._clear_right()
            self.focus = "cat"
        else:
            self._info_timer.stop()
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            self.close()

    def keyUp(self):
        w = {"cat":self["cat_list"],"ser":self["ser_list"],
             "sai":self["sai_list"],"ep":self["ep_list"]}.get(self.focus)
        if w: w.goLineUp()
        if self.focus == "ser": self._trigger_info()

    def keyDown(self):
        w = {"cat":self["cat_list"],"ser":self["ser_list"],
             "sai":self["sai_list"],"ep":self["ep_list"]}.get(self.focus)
        if w: w.goLineDown()
        if self.focus == "ser": self._trigger_info()

    def keyLeft(self):
        order = ["cat","ser","sai","ep"]
        if self.focus in order:
            idx = order.index(self.focus)
            if idx > 0: self.focus = order[idx-1]

    def keyRight(self):
        order = ["cat","ser","sai","ep"]
        if self.focus in order:
            idx = order.index(self.focus)
            next_w = {"cat":self.series_data,"ser":self.seasons,"sai":self.episodes,"ep":[]}
            if idx < len(order)-1 and next_w.get(self.focus):
                self.focus = order[idx+1]

    def exit(self):
        self._info_timer.stop(); self.close()
