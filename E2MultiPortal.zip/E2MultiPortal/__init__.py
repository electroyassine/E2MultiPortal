#!/usr/bin/python
# -*- coding: utf-8 -*-

from .main import E2MultiPortalMain
from .live import LiveScreen
from .vod import VodScreen
from .series import SeriesScreen
from .playlist import PlaylistScreen
from .servers_list import ServersListScreen, ServerFormScreen
from .server_manager import ServerManager

__version__     = "1.0.0"
__author__      = "E2MultiPortal"
__description__ = "IPTV Client — MAG/Stalker & Xtream Codes"

__all__ = [
    'E2MultiPortalMain',
    'LiveScreen',
    'VodScreen',
    'SeriesScreen',
    'PlaylistScreen',
    'ServersListScreen',
    'ServerFormScreen',
    'ServerManager',
]
