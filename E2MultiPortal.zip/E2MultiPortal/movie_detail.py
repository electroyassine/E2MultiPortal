#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
MovieDetailScreen - Fiche détail film/série sur écran séparé
Poster grand format + infos TMDB + bouton LIRE
"""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eServiceReference
import threading

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"

class MovieDetailScreen(Screen):

    skin = """
<screen name="MovieDetailScreen" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#04030e">
    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/vod.png" zPosition="-1"/>

    <!-- Poster grand format gauche -->
    <widget name="poster" position="60,60" size="400,580"
            zPosition="3" transparent="1" alphatest="on" scale="1"/>

    <!-- Fond poster (si pas d'image) -->
    <widget name="poster_bg" position="60,60" size="400,580"
            backgroundColor="#14102e" transparent="0" zPosition="2"/>

    <!-- Infos droite -->
    <widget name="title"  position="500,60"  size="1380,80"
            font="Bold;60" foregroundColor="#ffff00" transparent="1" zPosition="3"/>
    <widget name="year"   position="500,152" size="680,38"
            font="Regular;30" foregroundColor="#aaaaaa" transparent="1" zPosition="3"/>
    <widget name="rating" position="1180,152" size="700,38"
            font="Bold;32" halign="right" foregroundColor="#f39c12" transparent="1" zPosition="3"/>
    <widget name="genre"  position="500,196" size="1380,34"
            font="Regular;28" foregroundColor="#cccccc" transparent="1" zPosition="3"/>

    <!-- Synopsis -->
    <widget name="desc_lbl" position="500,248" size="1380,34"
            font="Bold;26" foregroundColor="#f1f90b" transparent="1" zPosition="3"/>
    <widget name="desc"  position="500,288" size="1380,420"
            font="Regular;26" foregroundColor="#dddddd" transparent="1" zPosition="3"/>

    <!-- Séparateur -->
    <eLabel position="60,660" size="1800,2" backgroundColor="#333366" zPosition="3"/>

    <!-- Bouton LIRE centré -->
    <widget name="btn_play" position="660,700" size="600,80"
            font="Bold;48" halign="center" valign="center"
            backgroundColor="#1a6e34" foregroundColor="#ffffff" zPosition="3"/>

    <!-- Hint -->
    <widget name="hint" position="0,800" size="1920,40"
            font="Regular;28" halign="center"
            foregroundColor="#336633" transparent="1" zPosition="3"/>

    <!-- Miniatures similaires (optionnel) -->
    <widget name="status" position="60,1040" size="800,28"
            font="Regular;22" foregroundColor="#334433" transparent="1" zPosition="3"/>

    <!-- Navigation hint bas -->
    <widget name="nav" position="0,1050" size="1920,26"
            font="Regular;20" halign="center"
            foregroundColor="#222244" transparent="1" zPosition="3"/>
</screen>""" % PLUGIN_PATH

    def __init__(self, session, movie, srv_type, base_url="", username="", password="",
                 mag_api=None, callback=None):
        Screen.__init__(self, session)
        from . import poster_manager as PM
        self._PM       = PM
        self.movie     = movie
        self.srv_type  = srv_type
        self.base_url  = base_url
        self.username  = username
        self.password  = password
        self._mag_api  = mag_api
        self._callback = callback

        self["poster"]    = Pixmap()
        self["poster_bg"] = Label("")
        self["title"]     = Label("")
        self["year"]      = Label("")
        self["rating"]    = Label("")
        self["genre"]     = Label("")
        self["desc_lbl"]  = Label("Synopsis")
        self["desc"]      = Label("")
        self["btn_play"]  = Label("  ▶  LIRE")
        self["hint"]      = Label("Vert / OK = Lire     EXIT = Retour")
        self["status"]    = Label("")
        self["nav"]       = Label("OK = Lire     EXIT = Retour a la grille")

        self["actions"] = ActionMap(
            ["OkCancelActions","ColorActions","DirectionActions"],
            {
                "ok":     self._play,
                "green":  self._play,
                "cancel": self._back,
                "red":    self._back,
                "up":     lambda: None,
                "down":   lambda: None,
                "left":   self._back,
                "right":  lambda: None,
            }, -1
        )
        self.onLayoutFinish.append(self._fill)

    def _fill(self):
        m    = self.movie
        name = m.get("name", "")
        raw_r = m.get("rating", m.get("rating_5based",""))

        self["title"].setText(name)
        if raw_r: self["rating"].setText("Note: %s" % raw_r)

        # Poster immédiat depuis serveur
        cover = self._PM.get_stream_icon(m)
        if cover:
            self._PM.load_and_show(self["poster"], cover)

        # TMDB
        def on_info(info):
            self["title"].setText(info.get("title", name))
            yr = info.get("year","")
            if yr: self["year"].setText(yr)
            rt = info.get("rating",0)
            if rt: self["rating"].setText("TMDB: %.1f/10" % rt)
            if info.get("genre"): self["genre"].setText(info["genre"])
            if info.get("desc"):  self["desc"].setText(info["desc"])

        def on_poster(url):
            self._PM.load_and_show(self["poster"], url)

        self._PM.fetch_tmdb_movie(name, on_info, on_poster, existing_cover=bool(cover))

    def _play(self):
        m    = self.movie
        name = m.get("name","Film")
        if self.srv_type == "xtream":
            vid = m.get("stream_id","")
            ext = m.get("container_extension","mp4")
            url = "%s/movie/%s/%s/%s.%s" % (
                self.base_url, self.username, self.password, vid, ext)
            self._open_player(url, name)
        else:
            url = m.get("cmd","")
            if url.startswith("ffmpeg "): url = url[7:].strip()
            if url.startswith("http"):
                self._open_player(url, name)
            else:
                self["status"].setText("Résolution MAG...")
                def resolve():
                    try:
                        r = self._mag_api.get_stream_url(m.get("cmd",""))
                        if r: self._open_player(r, name)
                        else: self["status"].setText("MAG: stream introuvable")
                    except Exception as e:
                        self["status"].setText("Erreur: %s" % str(e)[:40])
                threading.Thread(target=resolve, daemon=True).start()

    def _open_player(self, url, name):
        try:
            from .player import PlayerScreen
            self.session.openWithCallback(self._on_player_closed, PlayerScreen,
                                          url=url, name=name, parent_screen=self)
        except Exception as e:
            self["status"].setText("Erreur: %s" % str(e)[:50])

    def _on_player_closed(self, *args):
        self["status"].setText("")

    def _back(self):
        self.close()
