#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
LiveScreen - Live TV MAG/Stalker + Xtream
Lecture via PlayerScreen (transparent) : UP/DOWN revient à la liste.
"""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eServiceReference, eTimer, loadPNG
import json, os, ssl, urllib.request, urllib.parse, threading

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"
TMDB_KEY    = "4f4d38a3a9ab6f0c62a0a7c9b6d3e1a5"

class LiveScreen(Screen):

    skin = """
<screen name="LiveScreen" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#0d0d1a">
    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/live.png" zPosition="-1"/>

    <widget name="title"       position="0,22"   size="1920,58"
            font="Bold;46" halign="center" foregroundColor="#ffffff" transparent="1"/>
    <widget name="server_info" position="0,80"   size="1920,32"
            font="Regular;24" halign="center" foregroundColor="#aaaaaa" transparent="1"/>

    <!-- Bouquets (gauche) -->
    <widget name="bouquet_list" position="20,120" size="420,790"
            font="Regular;24" itemHeight="44"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>

    <!-- Chaînes (milieu) -->
    <widget name="channel_list" position="455,120" size="620,790"
            font="Regular;24" itemHeight="44"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>

    <!-- Poster (droite haut) -->
    <widget name="poster"       position="1095,120" size="250,355"
            zPosition="2" transparent="1" alphatest="on" scale="1"/>

    <!-- Info chaîne (droite bas) -->
    <widget name="info_name"   position="1095,485" size="805,50"
            font="Bold;32" foregroundColor="#ffff00" transparent="1"/>
    <widget name="info_num"    position="1095,537" size="400,30"
            font="Regular;23" foregroundColor="#aaaaaa" transparent="1"/>
    <widget name="info_group"  position="1095,570" size="805,30"
            font="Regular;22" foregroundColor="#cccccc" transparent="1"/>
    <widget name="info_epg"    position="1095,610" size="805,200"
            font="Regular;21" foregroundColor="#bbbbbb" transparent="1"/>

    <widget name="status"    position="20,928" size="1060,34"
            font="Regular;24" halign="left" foregroundColor="#00ff88" transparent="1"/>
    <widget name="page_info" position="1095,928" size="805,34"
            font="Regular;24" halign="right" foregroundColor="#888888" transparent="1"/>
</screen>""" % PLUGIN_PATH

    def __init__(self, session):
        Screen.__init__(self, session)

        from . import poster_manager as PM
        self._PM = PM
        self["title"]        = Label("Live TV")
        self["server_info"]  = Label("")
        self["bouquet_list"] = MenuList([], enableWrapAround=True)
        self["channel_list"] = MenuList([], enableWrapAround=True)
        self["poster"]       = Pixmap()
        self["info_name"]    = Label("")
        self["info_num"]     = Label("")
        self["info_group"]   = Label("")
        self["info_epg"]     = Label("")
        self["status"]       = Label("Chargement...")
        self["page_info"]    = Label("")

        self.srv_type   = None
        self.base_url   = ""
        self.username   = ""
        self.password   = ""
        self._mag_api   = None

        self.bouquets       = []
        self.channels       = []
        self.total_channels = 0
        self.max_page       = 1
        self.per_page       = 50
        self.cur_genre_id   = None
        self.cur_page       = 1
        self.focus          = "bouquet"
        self.b_idx          = 0

        self._info_timer = eTimer()
        self._info_timer.callback.append(self._deferred_info)
        self._pending_ch = None

        os.makedirs(self._PM.DIR_PERM, exist_ok=True)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions",
             "NumberActions", "MenuActions"],
            {
                "up":          self.keyUp,
                "down":        self.keyDown,
                "left":        self.keyLeft,
                "right":       self.keyRight,
                "ok":          self.keyOk,
                "cancel":      self.exit,
                "red":         self.exit,
                "green":       self.keyGreen,
                "yellow":      self.keyYellow,
                "blue":        self.keyBlue,
                "pageUp":      self.prevPage,
                "pageDown":    self.nextPage,
                "nextBouquet": self.nextBouquet,
                "prevBouquet": self.prevBouquet,
            }, -2
        )
        self.onLayoutFinish.append(self._start)

    # ── Init ─────────────────────────────────────────────────────────────────
    def _start(self):
        try:
            with open("/etc/enigma2/E2MultiPortal/servers.json") as f:
                data = json.load(f)
        except Exception:
            try:
                with open("/etc/enigma2/E2MultiPortal/portals.json") as f:
                    data = json.load(f)
            except Exception as e:
                self["status"].setText("Erreur config: %s" % str(e)[:40])
                return

        for s in data.get("servers", data.get("portals", [])):
            if not s.get("active"):
                continue
            st   = s.get("type", "stalker")
            name = s.get("name", "Serveur")
            self["server_info"].setText("%s (%s)" % (name, st.upper()))
            if st == "xtream":
                self.srv_type = "xtream"
                self.base_url = s.get("host", "").rstrip("/")
                self.username = s.get("username", "")
                self.password = s.get("password", "")
                self["title"].setText("Live TV — Xtream")
                threading.Thread(target=self._load_xtream_bouquets, daemon=True).start()
            elif st in ("mag", "stalker"):
                self.srv_type = "mag"
                host = s.get("host", "").rstrip("/")
                mac  = s.get("mac", "")
                self["title"].setText("Live TV — MAG/Stalker")
                try:
                    from .api_mag import MagAPI
                    self._mag_api = MagAPI(host, mac)
                except Exception:
                    self._mag_api = None
                threading.Thread(target=self._load_mag_bouquets, daemon=True).start()
            return
        self["status"].setText("Aucun serveur actif")

    # ── Headers MAG ──────────────────────────────────────────────────────────
    def _mag_headers(self, token=None):
        if self._mag_api:
            return self._mag_api._headers(token)
        return {"User-Agent": "E2MultiPortal/1.0"}

    def _mag_portal(self):
        if self._mag_api:
            return self._mag_api._server_url()
        return ""

    def _mag_token(self):
        if self._mag_api:
            return self._mag_api.get_token()
        return None

    # ── MAG Bouquets ─────────────────────────────────────────────────────────
    def _load_mag_bouquets(self):
        self["status"].setText("Chargement bouquets MAG...")
        try:
            # Utiliser MagAPI.get_genres() qui gère la detection automatique du chemin
            genres = self._mag_api.get_genres('itv') if self._mag_api else []
            if not genres:
                self["status"].setText("MAG: bouquets introuvables (vérifiez Host/MAC)")
                return
            self.bouquets = [{"id": g.get("id", ""), "name": g.get("title", g.get("name", "?"))}
                             for g in genres if isinstance(g, dict)]
            self["bouquet_list"].setList([b["name"] for b in self.bouquets])
            self["status"].setText("%d bouquets" % len(self.bouquets))
        except Exception as e:
            self["status"].setText("Erreur bouquets: %s" % str(e)[:40])
            print("[Live MAG] bouquets: %s" % e)

    def _load_mag_channels(self, genre_id, page=1):
        def work():
            try:
                # MagAPI.get_channels gère le bon chemin automatiquement
                if not self._mag_api:
                    self["status"].setText("MAG: API non initialisée")
                    return
                data = self._mag_api.get_channels(genre_id, page)
                # get_channels retourne une liste ou on refait l'appel raw pour total/maxpage
                token = self._mag_api.get_token()
                ctx = ssl._create_unverified_context()
                url = self._mag_api._server_url() + "?" + urllib.parse.urlencode({
                    "type": "itv", "action": "get_ordered_list",
                    "genre": str(genre_id), "p": str(page), "JsHttpRequest": "1-xml"
                })
                req = urllib.request.Request(url, headers=self._mag_api._headers(token))
                with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                    d = json.loads(r.read().decode("utf-8", "ignore"))
                js = d.get("js", {})
                if isinstance(js, dict):
                    self.channels       = js.get("data", [])
                    self.total_channels = js.get("total_items", len(self.channels))
                    self.max_page       = js.get("max_page", 1)
                elif isinstance(js, list):
                    self.channels       = js
                    self.total_channels = len(js)
                    self.max_page       = 1
                self._display_channels()
            except Exception as e:
                self["status"].setText("Erreur chaines: %s" % str(e)[:40])
                print("[Live MAG] channels: %s" % e)
        threading.Thread(target=work, daemon=True).start()

    # ── Xtream Bouquets/Channels ──────────────────────────────────────────────
    def _load_xtream_bouquets(self):
        self["status"].setText("Chargement categories...")
        from . import cache_manager as CM
        cache_key = "live_cats_%s_%s" % (self.base_url, self.username)

        def fetch():
            url = "%s/player_api.php?username=%s&password=%s&action=get_live_categories" % (
                self.base_url, self.username, self.password)
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers={"User-Agent": "E2MultiPortal/1.0"})
            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                data = json.loads(r.read().decode("utf-8", "ignore"))
            return [{"id": c.get("category_id", ""), "name": c.get("category_name", "?")}
                    for c in (data if isinstance(data, list) else []) if isinstance(c, dict)]

        try:
            self.bouquets, from_cache = CM.get_or_fetch(cache_key, fetch)
            self.bouquets = self.bouquets or []
            self["bouquet_list"].setList([b["name"] for b in self.bouquets])
            self["status"].setText(("%d categories (cache)" if from_cache else "%d categories") % len(self.bouquets))
        except Exception as e:
            self["status"].setText("Erreur categories: %s" % str(e)[:40])

    def _load_xtream_channels(self, cat_id, page=1):
        def work():
            try:
                url = "%s/player_api.php?username=%s&password=%s&action=get_live_streams&category_id=%s" % (
                    self.base_url, self.username, self.password, cat_id or "")
                ctx = ssl._create_unverified_context()
                req = urllib.request.Request(url, headers={"User-Agent": "E2MultiPortal/1.0"})
                with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                    data = json.loads(r.read().decode("utf-8", "ignore"))
                all_ch = data if isinstance(data, list) else []
                self.total_channels = len(all_ch)
                self.max_page = max(1, (self.total_channels + self.per_page - 1) // self.per_page)
                start = (page - 1) * self.per_page
                self.channels = all_ch[start: start + self.per_page]
                self.cur_page = page
                self._display_channels()
            except Exception as e:
                self["status"].setText("Erreur chaines: %s" % str(e)[:40])
        threading.Thread(target=work, daemon=True).start()

    # ── Affichage ─────────────────────────────────────────────────────────────
    def _load_channels(self, genre_id=None, page=1):
        self.cur_genre_id = genre_id
        self.cur_page     = page
        if self.srv_type == "mag":
            self._load_mag_channels(genre_id or "", page)
        elif self.srv_type == "xtream":
            self._load_xtream_channels(genre_id or "", page)

    def _display_channels(self):
        names = []
        for idx, ch in enumerate(self.channels):
            num  = ch.get("number", ch.get("num", ch.get("stream_id", idx + 1)))
            name = ch.get("name", "?")
            names.append("%s. %s" % (num, name))
        self["channel_list"].setList(names)
        self["page_info"].setText("Page %d/%d | %d chaines" % (
            self.cur_page, self.max_page, self.total_channels))
        self["status"].setText("%d chaines chargees" % len(self.channels))
        self.focus = "channel"
        # Info + poster du premier
        if self.channels:
            self._pending_ch = self.channels[0]
            self._info_timer.stop()
            self._info_timer.start(400, True)

    def _cur_channel(self):
        idx = self["channel_list"].getCurrentIndex()
        if 0 <= idx < len(self.channels):
            return self.channels[idx]
        return None

    # ── Info + Poster ─────────────────────────────────────────────────────────
    def _trigger_info(self):
        ch = self._cur_channel()
        if ch:
            self._pending_ch = ch
            self._info_timer.stop()
            self._info_timer.start(500, True)

    def _deferred_info(self):
        ch = self._pending_ch
        if not ch:
            return
        self._pending_ch = None
        name = ch.get("name", "")
        # Poster depuis le serveur (stream_icon, thumbnail, logo...)
        icon = self._PM.get_stream_icon(ch)
        if icon:
            self._PM.load_and_show(self["poster"], icon)
        else:
            try:
                self["poster"].hide()
            except Exception:
                pass
        # Infos texte
        self["info_name"].setText(name)
        num = ch.get("number", ch.get("num", ch.get("stream_id", "")))
        self["info_num"].setText("N° %s" % num if num else "")
        group = ch.get("category_name", ch.get("group_title", ""))
        self["info_group"].setText(group)
        self["info_epg"].setText("")

    def _load_poster(self, url):
        self._PM.load_and_show(self["poster"], url)

    # ── Lecture ───────────────────────────────────────────────────────────────
    def play_channel(self):
        ch = self._cur_channel()
        if not ch:
            self["status"].setText("Aucune chaine selectionnee")
            return

        name = ch.get("name", "Live")

        if self.srv_type == "mag":
            cmd = ch.get("cmd", "")
            if cmd.startswith("ffmpeg "):
                cmd = cmd[7:].strip()
            if cmd.startswith("http") or cmd.startswith("rtsp"):
                self._open_player(cmd, name)
            else:
                # Résolution create_link en thread
                self["status"].setText("Resolution stream MAG...")
                def resolve():
                    try:
                        url = None
                        if self._mag_api:
                            url = self._mag_api.get_stream_url(ch.get("cmd", ""))
                        if not url:
                            raw = ch.get("cmd", "")
                            if raw.startswith("ffmpeg "):
                                raw = raw[7:].strip()
                            if raw.startswith("http"):
                                url = raw
                        if url:
                            self._open_player(url, name)
                        else:
                            self["status"].setText("MAG: stream introuvable")
                    except Exception as e:
                        self["status"].setText("Erreur: %s" % str(e)[:40])
                threading.Thread(target=resolve, daemon=True).start()

        elif self.srv_type == "xtream":
            sid = ch.get("stream_id", "")
            ext = ch.get("container_extension", "ts")
            from urllib.parse import urlparse
            p   = urlparse(self.base_url)
            base = ("%s://%s" % (p.scheme, p.netloc)) if p.scheme else ("http://%s" % self.base_url)
            url = "%s/live/%s/%s/%s.%s" % (base, self.username, self.password, sid, ext)
            self._open_player(url, name)

    def _open_player(self, url, name):
        """Ouvre PlayerScreen par-dessus. L'écran Live reste en pile."""
        try:
            from .player import PlayerScreen
            self.session.openWithCallback(self._on_player_closed, PlayerScreen,
                                          url=url, name=name, parent_screen=self)
        except Exception as e:
            self["status"].setText("Erreur player: %s" % str(e)[:50])

    def _on_player_closed(self, *args):
        """Callback quand PlayerScreen se ferme : on est de retour dans Live."""
        self["status"].setText("Retour a la liste")

    # ── Navigation ────────────────────────────────────────────────────────────
    def keyOk(self):
        if self.focus == "bouquet":
            if self.bouquets:
                gid = self.bouquets[self.b_idx].get("id", self.bouquets[self.b_idx].get("category_id", ""))
                self._load_channels(gid, 1)
                self.focus = "channel"
        else:
            self.play_channel()

    def keyGreen(self):
        if self.focus == "channel":
            self.play_channel()

    def keyYellow(self):
        if self.cur_genre_id is not None:
            self._load_channels(self.cur_genre_id, self.cur_page)

    def keyBlue(self):
        self._load_channels("", 1)

    def keyUp(self):
        if self.focus == "bouquet":
            self["bouquet_list"].goLineUp()
            self.b_idx = self["bouquet_list"].getCurrentIndex()
        else:
            self["channel_list"].goLineUp()
            self._trigger_info()

    def keyDown(self):
        if self.focus == "bouquet":
            self["bouquet_list"].goLineDown()
            self.b_idx = self["bouquet_list"].getCurrentIndex()
        else:
            self["channel_list"].goLineDown()
            self._trigger_info()

    def keyLeft(self):
        self.focus = "bouquet"

    def keyRight(self):
        if self.channels:
            self.focus = "channel"
            self._trigger_info()

    def prevPage(self):
        if self.cur_page > 1:
            self._load_channels(self.cur_genre_id, self.cur_page - 1)

    def nextPage(self):
        if self.cur_page < self.max_page:
            self._load_channels(self.cur_genre_id, self.cur_page + 1)

    def nextBouquet(self):
        if self.bouquets:
            self.b_idx = min(self.b_idx + 1, len(self.bouquets) - 1)
            self["bouquet_list"].setCurrentIndex(self.b_idx)

    def prevBouquet(self):
        if self.bouquets:
            self.b_idx = max(self.b_idx - 1, 0)
            self["bouquet_list"].setCurrentIndex(self.b_idx)

    def exit(self):
        self._info_timer.stop()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close()
