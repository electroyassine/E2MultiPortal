#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
VodScreen - Mode liste classique
Gauche: categories | Centre: liste films (texte) | Droite: poster+infos du film selectionne
Vert = Lire directement
"""
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from enigma import eTimer, gRGB
import json, os, ssl, urllib.request, urllib.parse, threading

CONFIG_FILE = "/etc/enigma2/E2MultiPortal/servers.json"
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"

class VodScreen(Screen):

    skin = """
<screen name="VodScreen" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#06050f">
    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/vod.png" zPosition="-1"/>

    <widget name="title"       position="0,8"   size="1920,46"
            font="Bold;38" halign="center" foregroundColor="#ffffff" transparent="1"/>
    <widget name="server_info" position="0,54"  size="1920,26"
            font="Regular;20" halign="center" foregroundColor="#aaaaaa" transparent="1"/>

    <!-- COLONNE 1: Categories x=20 w=330 -->
    <widget name="cat_lbl"  position="20,84"  size="330,32"
            font="Bold;22" halign="center" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="cat_list" position="20,120" size="330,900"
            font="Regular;20" itemHeight="36"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>

    <!-- COLONNE 2: Liste films x=362 w=560 -->
    <widget name="mov_lbl"  position="362,84" size="420,32"
            font="Bold;22" halign="left" foregroundColor="#f1f90b" transparent="1"/>
    <widget name="pg_info"  position="650,84" size="270,32"
            font="Regular;19" halign="right" foregroundColor="#666688" transparent="1"/>
    <widget name="mov_list" position="362,120" size="560,900"
            font="Regular;22" itemHeight="38"
            foregroundColorSelected="#ffffff" foregroundColor="#2a2014"
            backgroundColorSelected="#3a3aaa" backgroundColor="#b49e86"
            scrollbarMode="showOnDemand"/>

    <!-- COLONNE 3: Poster + infos x=938 w=962 -->
    <eLabel position="938,84" size="962,936" backgroundColor="#b49e86" zPosition="1"/>
    <eLabel position="938,84" size="2,936"   backgroundColor="#2a2a5a" zPosition="2"/>

    <widget name="poster"    position="952,100" size="290,430"
            zPosition="3" transparent="1" alphatest="on" scale="1"/>
    <widget name="poster_bg" position="952,100" size="290,430"
            backgroundColor="#b49e86" transparent="0" zPosition="2"/>

    <widget name="info_title"  position="1262,105" size="620,65"
            font="Bold;38" foregroundColor="#ffff00" transparent="1" zPosition="3"/>
    <widget name="info_year"   position="1262,178" size="310,30"
            font="Regular;24" foregroundColor="#2a2014" transparent="1" zPosition="3"/>
    <widget name="info_rating" position="1572,178" size="310,30"
            font="Bold;26" halign="right" foregroundColor="#f39c12" transparent="1" zPosition="3"/>
    <widget name="info_genre"  position="1262,214" size="620,28"
            font="Regular;22" foregroundColor="#2a2014" transparent="1" zPosition="3"/>
    <widget name="info_desc"   position="1262,250" size="620,280"
            font="Regular;21" foregroundColor="#2a2014" transparent="1" zPosition="3"/>

    <!-- Bouton LIRE -->
    <eLabel position="952,546" size="920,2" backgroundColor="#2a2a5a" zPosition="3"/>
    <widget name="btn_play" position="1082,570" size="360,60"
            font="Bold;36" halign="center" valign="center"
            backgroundColor="#1a6e34" foregroundColor="#ffffff" zPosition="3"/>
    <widget name="btn_search" position="1082,640" size="360,55"
            font="Bold;28" halign="center" valign="center"
            backgroundColor="#2980b9" foregroundColor="#ffffff" zPosition="3"/>
    <widget name="hint" position="952,710" size="920,30"
            font="Regular;22" halign="center" foregroundColor="#446644" transparent="1" zPosition="3"/>

    <!-- Pagination -->
    <widget name="pag_info" position="952,1022" size="920,44"
            font="Regular;24" halign="center" foregroundColor="#888888" transparent="1" zPosition="3"/>

    <widget name="status" position="20,1042" size="330,30"
            font="Regular;20" halign="center" foregroundColor="#004422" transparent="1" zPosition="3"/>
</screen>""" % PLUGIN_PATH

    PER_PAGE = 100

    def __init__(self, session):
        Screen.__init__(self, session)
        from . import poster_manager as PM
        self._PM = PM

        self["title"]       = Label("VOD — Video a la Demande")
        self["server_info"] = Label("")
        self["cat_lbl"]     = Label("CATEGORIES")
        self["mov_lbl"]     = Label("")
        self["pg_info"]     = Label("")
        self["status"]      = Label("")
        self["cat_list"]    = MenuList([], enableWrapAround=True)
        self["mov_list"]    = MenuList([], enableWrapAround=True)
        self["poster"]      = Pixmap()
        self["poster_bg"]   = Label("")
        self["info_title"]  = Label("")
        self["info_year"]   = Label("")
        self["info_rating"] = Label("")
        self["info_genre"]  = Label("")
        self["info_desc"]   = Label("")
        self["btn_play"]    = Label("  ▶  LIRE")
        self["btn_search"]  = Label("  \U0001F50D  RECHERCHE")
        self["hint"]        = Label("Vert = Lire   Bleu = Recherche   EXIT = Categories")
        self["pag_info"]    = Label("")

        self.categories   = []
        self.movies       = []
        self.cur_cat_id   = ""
        self.cur_cat_name = ""
        self.page         = 0
        self.total_pages  = 1
        self.total_count  = 0
        self.focus        = "cat"
        self.srv_type     = None
        self.base_url     = ""
        self.username     = ""
        self.password     = ""
        self._mag_srv     = None
        self._mag_api     = None

        self._info_timer  = eTimer()
        self._info_timer.callback.append(self._load_info)

        self["actions"] = ActionMap(
            ["DirectionActions","OkCancelActions","ColorActions","MenuActions"],
            {
                "up":       self.keyUp,
                "down":     self.keyDown,
                "left":     self.keyLeft,
                "right":    self.keyRight,
                "ok":       self.keyOk,
                "cancel":   self.keyBack,
                "red":      self.keyBack,
                "green":    self.keyPlay,
                "yellow":   self.prevPage,
                "blue":     self.do_search,
                "pageUp":   self.prevPage,
                "pageDown": self.nextPage,
                "menu":     self.keyRefresh,
            }, -1
        )
        self.onLayoutFinish.append(self._start)

    # ── Init ──────────────────────────────────────────────────────────────────
    def _start(self):
        self._clear_right()
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            for s in data.get("servers", []):
                if not s.get("active"): continue
                st = s.get("type","mag")
                self["server_info"].setText("%s (%s)" % (s.get("name",""), st.upper()))
                if st == "xtream":
                    self.srv_type = "xtream"
                    self.base_url = s.get("host","").rstrip("/")
                    self.username = s.get("username","")
                    self.password = s.get("password","")
                    threading.Thread(target=self._load_xtream_cats, daemon=True).start()
                elif st in ("mag","stalker"):
                    self.srv_type = "mag"
                    self._mag_srv = s
                    threading.Thread(target=self._load_mag_cats, daemon=True).start()
                return
            self["status"].setText("Aucun serveur actif")
        except Exception as e:
            self["status"].setText("Erreur: %s" % str(e)[:50])

    # ── Recherche ─────────────────────────────────────────────────────────────
    def do_search(self):
        self.session.openWithCallback(
            self._search_done, VirtualKeyBoard,
            title="Rechercher un film (nom ou partie du nom)", text="")

    def _search_done(self, text):
        if not text:
            return
        text = text.strip()
        if not text:
            return
        self["status"].setText("Recherche...")
        threading.Thread(target=self._perform_search, args=(text,), daemon=True).start()

    def _perform_search(self, query):
        try:
            # Recharge (ou recupere du cache) la liste complete "Toutes"
            if self.srv_type == "xtream":
                self._load_xtream_movies("")
            else:
                self._load_mag_movies("")

            q = query.strip().lower()
            results = [m for m in self.movies if q in (m.get("name","") or "").lower()]

            self.movies = results
            self.cur_cat_id = "__search__"
            self.cur_cat_name = "Recherche : '%s'  (%d resultat%s)" % (
                query, len(results), "s" if len(results) != 1 else "")
            self.total_count = len(results)
            self.total_pages = max(1, (self.total_count + self.PER_PAGE - 1) // self.PER_PAGE)
            self.page = 0
            self["status"].setText("")
            self._display_page()
        except Exception as e:
            self["status"].setText("Erreur recherche: %s" % str(e)[:60])

    def keyRefresh(self):
        """Rafraichissement manuel (touche MENU) : relance le chargement,
        ce qui retente le serveur et met a jour le cache en cas de succes."""
        self["status"].setText("Rafraichissement...")
        self["cat_list"].setList([])
        self.categories = []
        self.movies = []
        self._clear_list()
        threading.Thread(target=self._start, daemon=True).start()

    def _clear_right(self):
        for w in ("info_title","info_year","info_rating","info_genre","info_desc"):
            self[w].setText("")
        try: self["poster"].hide()
        except: pass

    # ── Réseau ────────────────────────────────────────────────────────────────
    def _xurl(self, action, extra=""):
        return "%s/player_api.php?username=%s&password=%s&action=%s%s" % (
            self.base_url, self.username, self.password, action, extra)

    def _fetch(self, url, timeout=20):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers={"User-Agent":"E2MultiPortal/1.0"})
            with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","ignore"))
        except Exception as e:
            print("[VOD] %s" % e); return None

    # ── Xtream ────────────────────────────────────────────────────────────────
    def _load_xtream_cats(self):
        self["status"].setText("Chargement...")
        from . import cache_manager as CM
        cache_key = "vod_cats_%s_%s" % (self.base_url, self.username)

        def fetch():
            d = self._fetch(self._xurl("get_vod_categories"))
            out = []
            if isinstance(d, list):
                for c in d:
                    if isinstance(c, dict):
                        out.append({"id": c.get("category_id", ""), "name": c.get("category_name", "?")})
            return out

        raw, from_cache = CM.get_or_fetch(cache_key, fetch)
        cats = [{"id":"","name":"Toutes les categories"}] + (raw or [])
        self.categories = cats
        self["cat_list"].setList([c["name"] for c in cats])
        self["status"].setText("Categories (cache)" if from_cache else "")
        self.focus = "cat"

    def _load_xtream_movies(self, cat_id, page=0):
        self["status"].setText("Chargement films...")
        from . import cache_manager as CM
        cache_key = "vod_movies_%s_%s_%s" % (self.base_url, self.username, cat_id or "all")
        extra = ("&category_id=%s" % cat_id) if cat_id else ""

        def fetch():
            d = self._fetch(self._xurl("get_vod_streams", extra))
            return d if isinstance(d, list) else []

        movies, from_cache = CM.get_or_fetch(cache_key, fetch)
        self.movies = movies or []
        self.total_count = len(self.movies)
        self.total_pages = max(1,(self.total_count+self.PER_PAGE-1)//self.PER_PAGE)
        self.page = page
        self["status"].setText("Films (cache)" if from_cache else "")
        self._display_page()

    # ── MAG ───────────────────────────────────────────────────────────────────
    def _load_mag_cats(self):
        self["status"].setText("MAG: connexion...")
        try:
            from .api_mag import MagAPI
            srv = self._mag_srv
            self._mag_api = MagAPI(srv.get("host",""), srv.get("mac",""))
            token = self._mag_api.get_token()
            if not token: self["status"].setText("MAG: token introuvable"); return
            ctx = ssl._create_unverified_context()
            cats_raw = []
            for action in ("get_categories","get_genres"):
                try:
                    url = self._mag_api._server_url()+"?type=vod&action=%s&JsHttpRequest=1-xml"%action
                    req = urllib.request.Request(url,headers=self._mag_api._headers(token))
                    with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
                        d = json.loads(r.read().decode("utf-8","ignore"))
                    js = d.get("js",[]); js = js.get("data",[]) if isinstance(js,dict) else js
                    if js: cats_raw=js; break
                except: pass
            self.categories = [{"id":"","name":"Toutes"}]
            for c in cats_raw:
                if isinstance(c,dict):
                    self.categories.append({"id":c.get("id",""),"name":c.get("title",c.get("name","?"))})
            self["cat_list"].setList([c["name"] for c in self.categories])
            self["status"].setText("")
            self.focus = "cat"
        except Exception as e:
            self["status"].setText("MAG: %s"%str(e)[:60])

    def _load_mag_movies(self, cat_id, page=0):
        self["status"].setText("MAG: chargement...")
        try:
            token = self._mag_api.get_token()
            ctx = ssl._create_unverified_context()
            params = "type=vod&action=get_ordered_list&p=1&JsHttpRequest=1-xml"
            if cat_id: params += "&category=%s"%cat_id
            url = self._mag_api._server_url()+"?"+params
            req = urllib.request.Request(url,headers=self._mag_api._headers(token))
            with urllib.request.urlopen(req,context=ctx,timeout=20) as r:
                d = json.loads(r.read().decode("utf-8","ignore"))
            js = d.get("js",{})
            items = js.get("data",[]) if isinstance(js,dict) else []
            self.movies = items
            self.total_count = len(items)
            self.total_pages = max(1,(self.total_count+self.PER_PAGE-1)//self.PER_PAGE)
            self.page = page
            self["status"].setText("")
            self._display_page()
        except Exception as e:
            self["status"].setText("MAG: %s"%str(e)[:60])

    # ── Affichage liste ────────────────────────────────────────────────────────
    def _display_page(self):
        start = self.page * self.PER_PAGE
        items = self.movies[start:start+self.PER_PAGE]
        self["mov_list"].setList([m.get("name","?") for m in items])
        self["mov_lbl"].setText(self.cur_cat_name)
        self["pg_info"].setText("Page %d/%d" % (self.page+1, self.total_pages))
        self["pag_info"].setText("%d/%d  |  %d films" % (self.page+1,self.total_pages,self.total_count))
        self._clear_right()
        self.focus = "mov"
        # Auto-afficher infos du 1er film
        self._info_timer.stop()
        self._info_timer.start(500, True)

    def _cur_movie(self):
        idx = self["mov_list"].getCurrentIndex()
        real = self.page*self.PER_PAGE + idx
        if 0 <= real < len(self.movies): return self.movies[real]
        return None

    # ── Infos + Poster ────────────────────────────────────────────────────────
    def _trigger_info(self):
        self._info_timer.stop()
        self._info_timer.start(400, True)

    def _load_info(self):
        m = self._cur_movie()
        if not m: return
        name = m.get("name","")
        # Infos brutes immédiates
        self["info_title"].setText(name)
        raw_r = m.get("rating",m.get("rating_5based",""))
        if raw_r: self["info_rating"].setText("Note: %s"%raw_r)
        # Poster serveur
        cover = self._PM.get_stream_icon(m)
        if cover:
            self._PM.load_and_show(self["poster"], cover)
        else:
            try: self["poster"].hide()
            except: pass
        # TMDB
        def on_info(info):
            self["info_title"].setText(info.get("title",name))
            yr = info.get("year","")
            if yr: self["info_year"].setText(yr)
            rt = info.get("rating",0)
            if rt: self["info_rating"].setText("TMDB: %.1f/10"%rt)
            if info.get("genre"): self["info_genre"].setText(info["genre"])
            if info.get("desc"):  self["info_desc"].setText(info["desc"])
        def on_poster(url):
            self._PM.load_and_show(self["poster"], url)
        self._PM.fetch_tmdb_movie(self._PM.clean_title(name), on_info, on_poster, existing_cover=bool(cover))

    # ── Lecture ───────────────────────────────────────────────────────────────
    def keyPlay(self):
        if self.focus != "mov": return
        m = self._cur_movie()
        if not m: return
        name = m.get("name","VOD")
        if self.srv_type == "xtream":
            vid = m.get("stream_id","")
            ext = m.get("container_extension","mp4")
            url = "%s/movie/%s/%s/%s.%s"%(self.base_url,self.username,self.password,vid,ext)
            self._open_player(url,name)
        else:
            url = m.get("cmd","")
            if url.startswith("ffmpeg "): url=url[7:].strip()
            if url.startswith("http"):
                self._open_player(url,name)
            else:
                self["status"].setText("Resolution MAG...")
                def resolve():
                    try:
                        r = self._mag_api.get_stream_url(m.get("cmd",""))
                        if r: self._open_player(r,name)
                        else: self["status"].setText("MAG: introuvable")
                    except Exception as e:
                        self["status"].setText("Err: %s"%str(e)[:40])
                threading.Thread(target=resolve,daemon=True).start()

    def _open_player(self, url, name):
        try:
            from .player import PlayerScreen
            self.session.openWithCallback(lambda *r: None, PlayerScreen,
                                          url=url, name=name, parent_screen=self)
        except Exception as e:
            self["status"].setText("Erreur: %s"%str(e)[:50])

    # ── Navigation ────────────────────────────────────────────────────────────
    def keyOk(self):
        if self.focus == "cat":
            idx = self["cat_list"].getCurrentIndex()
            if 0 <= idx < len(self.categories):
                c = self.categories[idx]
                self.cur_cat_id = c["id"]
                self.cur_cat_name = c["name"]
                if self.srv_type == "xtream":
                    threading.Thread(target=self._load_xtream_movies,args=(c["id"],0),daemon=True).start()
                else:
                    threading.Thread(target=self._load_mag_movies,args=(c["id"],0),daemon=True).start()
        elif self.focus == "mov":
            self.keyPlay()

    def keyBack(self):
        if self.focus == "mov":
            self["mov_list"].setList([])
            self["mov_lbl"].setText("")
            self["pg_info"].setText("")
            self["pag_info"].setText("")
            self._clear_right()
            self.movies = []
            self.focus = "cat"
        else:
            self._info_timer.stop()
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            self.close()

    def keyUp(self):
        if self.focus == "cat": self["cat_list"].goLineUp()
        elif self.focus == "mov":
            self["mov_list"].goLineUp(); self._trigger_info()

    def keyDown(self):
        if self.focus == "cat": self["cat_list"].goLineDown()
        elif self.focus == "mov":
            self["mov_list"].goLineDown(); self._trigger_info()

    def keyLeft(self):
        if self.focus == "mov": self.focus = "cat"

    def keyRight(self):
        if self.focus == "cat" and self.movies:
            self.focus = "mov"

    def prevPage(self):
        if self.focus == "mov" and self.page > 0:
            self.page -= 1; self._display_page()

    def nextPage(self):
        if self.focus == "mov" and self.page < self.total_pages-1:
            self.page += 1; self._display_page()

    def exit(self):
        self._info_timer.stop()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close()
