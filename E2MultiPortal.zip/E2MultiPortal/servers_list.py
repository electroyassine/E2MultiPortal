#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
ServersListScreen  - Gestion des serveurs : ajout, édition, suppression
ServerFormScreen   - Formulaire Add/Edit avec test de connexion
Inspiré d'EbroStream — adapté pour E2MultiPortal (MAG + Xtream)
"""

import os
import json
import uuid
from datetime import datetime

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.config import (ConfigSubsection, ConfigText, ConfigPassword,
                                ConfigSelection, getConfigListEntry)
from enigma import gRGB

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"
CONFIG_FILE = "/etc/enigma2/E2MultiPortal/servers.json"


# ══════════════════════════════════════════════════════════════════════════════
#  FORMULAIRE AJOUT / EDITION
# ══════════════════════════════════════════════════════════════════════════════

class ServerFormScreen(ConfigListScreen, Screen):
    """Formulaire Add/Edit — identique à EbroStream — avec test connexion"""

    skin = """
<screen position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#010103">

    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/config.png" zPosition="-1"/>

    <widget name="title" position="0,68" size="1920,72"
            font="Bold;54" halign="center" valign="center"
            foregroundColor="#2ecc71" transparent="1" zPosition="2"/>
    <eLabel position="760,150" size="400,4" backgroundColor="#b49e86" zPosition="2"/>

    <!-- Carte du formulaire (bordure accent + panneau sombre) -->
    <eLabel position="158,190" size="1604,496" backgroundColor="#b49e86" zPosition="0"/>
    <eLabel position="162,194" size="1596,488" backgroundColor="#19181c" zPosition="1"/>

    <widget name="config" position="182,212" size="1556,452"
            itemHeight="70" backgroundColor="#19181c"
            backgroundColorSelected="#b49e86" foregroundColor="#e8e8e8"
            foregroundColorSelected="#1a1208"
            scrollbarMode="showOnDemand" zPosition="2"/>

    <widget name="test_result" position="160,705" size="1600,50"
            font="Bold;28" halign="center" valign="center"
            foregroundColor="#f39c12" transparent="1" zPosition="2"/>

    <!-- Boutons (centres) -->
    <widget name="btn_test"   position="380,800"  size="320,72"
            font="Bold;30" halign="center" valign="center"
            backgroundColor="#f39c12" foregroundColor="#000" zPosition="2"/>
    <widget name="btn_save"   position="800,800"  size="320,72"
            font="Bold;30" halign="center" valign="center"
            backgroundColor="#27ae60" foregroundColor="#fff" zPosition="2"/>
    <widget name="btn_cancel" position="1220,800" size="320,72"
            font="Bold;30" halign="center" valign="center"
            backgroundColor="#e74c3c" foregroundColor="#fff" zPosition="2"/>

</screen>""" % PLUGIN_PATH

    def __init__(self, session, mode="add", server_data=None, server_index=None):
        Screen.__init__(self, session)

        self.mode         = mode          # "add" ou "edit"
        self.server_index = server_index
        self.server_data  = server_data or {}
        self._tested      = False
        self._tested_expiration = self.server_data.get("expiration", "")

        title_text = "ADD NEW SERVER" if mode == "add" else "EDIT SERVER"
        self["title"]       = Label(title_text)
        self["test_result"] = Label("Testez la connexion avant d'enregistrer")
        self["btn_test"]    = Button("TEST")
        self["btn_save"]    = Button("SAVE")
        self["btn_cancel"]  = Button("CANCEL")

        # Champs
        self.cf = ConfigSubsection()
        self.cf.name   = ConfigText(
            default=self.server_data.get("name", ""), fixed_size=False)
        self.cf.stype  = ConfigSelection(
            choices=[("mag", "Stalker Portal"), ("xtream", "Xtream Codes")],
            default=self.server_data.get("type", "mag"))
        self.cf.host   = ConfigText(
            default=self.server_data.get("host", self.server_data.get("url", "http://")),
            fixed_size=False)
        self.cf.mac    = ConfigText(
            default=self.server_data.get("mac", "00:1A:79:XX:XX:XX"), fixed_size=False)
        self.cf.user   = ConfigText(
            default=self.server_data.get("username", self.server_data.get("user", "")),
            fixed_size=False)
        self.cf.passwd = ConfigPassword(
            default=self.server_data.get("password", ""), fixed_size=False)
        self.cf.port   = ConfigText(
            default=str(self.server_data.get("port", 80)), fixed_size=False)

        ConfigListScreen.__init__(self, [], session=session)
        self._build_list()

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions", "OkCancelActions", "DirectionActions"],
            {
                "ok":     self.keyOK,
                "cancel": self.cancel,
                "red":    self.cancel,
                "green":  self.save,
                "yellow": self.do_test,
                "blue":   self.do_test,
                "left":   self._key_left,
                "right":  self._key_right,
                "up":     self.keyUp,
                "down":   self.keyDown,
            }, -2
        )

    # ─── Liste config ──────────────────────────────────────────────────────────

    def _build_list(self):
        entries = [
            getConfigListEntry("Server Name", self.cf.name),
            getConfigListEntry("Server Type", self.cf.stype),
            getConfigListEntry("Server URL",  self.cf.host),
        ]
        if self.cf.stype.value == "mag":
            entries.append(getConfigListEntry("MAC Address", self.cf.mac))
        else:
            entries.append(getConfigListEntry("Port",       self.cf.port))
            entries.append(getConfigListEntry("Username",   self.cf.user))
            entries.append(getConfigListEntry("Password",   self.cf.passwd))
        self["config"].setList(entries)

    def _key_left(self):
        ConfigListScreen.keyLeft(self)
        cur = self["config"].getCurrent()
        if cur and cur[1] == self.cf.stype:
            self._build_list()

    def _key_right(self):
        ConfigListScreen.keyRight(self)
        cur = self["config"].getCurrent()
        if cur and cur[1] == self.cf.stype:
            self._build_list()

    def keyOK(self):
        cur = self["config"].getCurrent()
        if not cur:
            return
        cfg = cur[1]
        if cfg == self.cf.stype:
            # Basculer le type
            choices = [c[0] for c in cfg.choices]
            idx = choices.index(cfg.value)
            cfg.value = choices[(idx + 1) % len(choices)]
            self._build_list()
        elif hasattr(cfg, "value") and isinstance(cfg.value, str):
            self.session.openWithCallback(
                lambda t: self._kb_done(t, cfg),
                VirtualKeyBoard,
                title=cur[0],
                text=cfg.value
            )

    def _kb_done(self, text, cfg):
        if text is not None:
            cfg.value = text
            self._build_list()

    # ─── Test connexion ────────────────────────────────────────────────────────

    def do_test(self):
        self._tested = False
        self._tested_expiration = ""
        host = self.cf.host.value.strip()
        if not host or host == "http://":
            self["test_result"].setText("Entrez d'abord l'URL du serveur")
            return
        self["test_result"].setText("Test en cours...")
        stype = self.cf.stype.value
        if stype == "mag":
            mac = self.cf.mac.value.strip()
            if not mac or "X" in mac.upper():
                self["test_result"].setText("Entrez une adresse MAC valide (ex: 00:1A:79:AB:CD:EF)")
                return
            self._test_mag(host, mac)
        else:
            user   = self.cf.user.value.strip()
            passwd = self.cf.passwd.value.strip()
            raw    = self.cf.port.value.strip()
            try:
                port = int(raw) if raw else 80
            except ValueError:
                port = 80
            if not user:
                self["test_result"].setText("Entrez un nom d'utilisateur")
                return
            self._test_xtream(host, user, passwd, port)

    def _test_mag(self, host, mac):
        try:
            from .api_mag import MagAPI
            result = MagAPI(host, mac).test_connection()
            if result.get("success"):
                msg = "OK - " + result.get("message", "Portail accessible")
                exp = result.get("expiration", "")
                exp_raw = result.get("expiration_raw", "")
                if exp:
                    msg += " - Expire: %s" % exp
                    if exp == "Illimite" and exp_raw:
                        msg += " (brut: %s)" % str(exp_raw)[:30]
                    self._tested_expiration = exp
                self["test_result"].setText(msg)
                self._tested = True
            else:
                self["test_result"].setText("ERREUR: " + result.get("message", "Echec"))
        except Exception as e:
            self["test_result"].setText("ERREUR: %s" % str(e)[:80])

    def _test_xtream(self, host, user, passwd, port):
        try:
            from .api_xtream import XtreamAPI
            result = XtreamAPI(host, user, passwd, port).test_connection()
            if result.get("success"):
                exp = result.get("expiration", "")
                try:
                    if exp and str(exp).strip().isdigit():
                        from datetime import datetime as dt
                        exp = dt.fromtimestamp(int(exp)).strftime("%d/%m/%Y")
                except:
                    pass
                msg = "OK [%s]" % result.get("status", "active")
                if exp and exp != "N/A":
                    msg += " - Expire: %s" % exp
                    self._tested_expiration = exp
                self["test_result"].setText(msg)
                self._tested = True
            else:
                self["test_result"].setText("ERREUR: " + result.get("message", "Echec"))
        except Exception as e:
            self["test_result"].setText("ERREUR: %s" % str(e)[:80])

    # ─── Sauvegarde ───────────────────────────────────────────────────────────

    def save(self):
        name  = self.cf.name.value.strip()
        stype = self.cf.stype.value
        host  = self.cf.host.value.strip().rstrip("/")

        if not name:
            self.session.open(MessageBox, "Le nom est obligatoire", MessageBox.TYPE_ERROR)
            return
        if not host or host == "http:":
            self.session.open(MessageBox, "L'URL est obligatoire", MessageBox.TYPE_ERROR)
            return
        if not host.startswith(("http://", "https://")):
            self.session.open(MessageBox, "L'URL doit commencer par http:// ou https://", MessageBox.TYPE_ERROR)
            return

        if not self._tested:
            self.session.openWithCallback(self._save_anyway, MessageBox,
                "Connexion non testee. Enregistrer quand meme ?",
                MessageBox.TYPE_YESNO)
        else:
            self._do_save()

    def _save_anyway(self, result):
        if result:
            self._do_save()

    def _do_save(self):
        name  = self.cf.name.value.strip()
        stype = self.cf.stype.value
        host  = self.cf.host.value.strip().rstrip("/")
        raw   = self.cf.port.value.strip()
        try:
            port = int(raw) if raw else 80
        except ValueError:
            port = 80

        server = {
            "id":     self.server_data.get("id", str(uuid.uuid4())[:8]),
            "type":   stype,
            "name":   name,
            "host":   host,
            "active": self.server_data.get("active", False),
        }
        if stype == "mag":
            server["mac"] = self.cf.mac.value.strip()
        else:
            server["username"] = self.cf.user.value.strip()
            server["password"] = self.cf.passwd.value.strip()
            server["port"]     = port

        # Charger + modifier
        servers = []
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE) as f:
                    d = json.load(f)
                servers = d.get("servers", []) if isinstance(d, dict) else d
        except:
            pass

        # Date d'expiration : priorite a un test frais ; sinon on conserve
        # celle deja enregistree pour ce serveur (ne pas l'effacer si on
        # enregistre sans re-tester).
        exp = self._tested_expiration
        if not exp and self.mode == "edit" and self.server_index is not None and self.server_index < len(servers):
            exp = servers[self.server_index].get("expiration", "")
        if exp:
            server["expiration"] = exp

        if self.mode == "edit" and self.server_index is not None and self.server_index < len(servers):
            server["active"] = servers[self.server_index].get("active", False)
            servers[self.server_index] = server
            msg = "Serveur '%s' modifie !" % name
        else:
            servers.append(server)
            msg = "Serveur '%s' ajoute !" % name

        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump({"servers": servers,
                           "last_updated": str(datetime.now())}, f, indent=2, ensure_ascii=False)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=2)
            self.close(True)
        except Exception as e:
            self.session.open(MessageBox, "Erreur sauvegarde: %s" % e, MessageBox.TYPE_ERROR)

    def cancel(self):
        self.close(False)

    def close(self, result=None):
        super().close(result)


# ══════════════════════════════════════════════════════════════════════════════
#  LISTE DES SERVEURS  (grille 4x3)
# ══════════════════════════════════════════════════════════════════════════════

class ServersListScreen(Screen):
    """Grille 4x3 — tous les serveurs, ajout/édition/suppression"""

    GRID_COLS = 4
    GRID_ROWS = 3
    PER_PAGE  = 12

    GX, GY   = 100, 200
    CW, CH   = 400, 180
    SX, SY   = 30,  30

    IW, IH   = 280, 100
    IX_OFF   = (CW - IW) // 2
    IY_OFF   = 15
    LY_OFF   = CH - 40
    LH       = 35

    ICON_MAG    = PLUGIN_PATH + "/skins/iconS.png"
    ICON_XTREAM = PLUGIN_PATH + "/skins/iconX.png"

    def __init__(self, session):
        Screen.__init__(self, session)

        self["title"]    = Label("SERVER SELECTION")
        self["pg_info"]  = Label("")
        self["status"]   = Label("")

        self["btn_add"]     = Button("ADD")
        self["btn_edit"]    = Button("EDIT")
        self["btn_delete"]  = Button("DELETE")
        self["btn_player"]  = Button("PLAYER")

        self.grid_bgs  = []
        self.grid_pxs  = []
        self.grid_lbls = []
        for i in range(self.PER_PAGE):
            self["gb_%d" % i] = Pixmap()
            self["gp_%d" % i] = Pixmap()
            self["gl_%d" % i] = Label("")
            self.grid_bgs.append("gb_%d" % i)
            self.grid_pxs.append("gp_%d" % i)
            self.grid_lbls.append("gl_%d" % i)

        self.servers = []
        self.sel     = 0
        self.page    = 0

        self.skin = self._gen_skin()
        self._load()

        self.onLayoutFinish.append(self._refresh)

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up":     self.keyUp,
                "down":   self.keyDown,
                "left":   self.keyLeft,
                "right":  self.keyRight,
                "ok":     self.do_connect,
                "cancel": self.close,
                "red":    self.do_delete,
                "green":  self.do_add,
                "yellow": self.do_edit,
                "blue":   self.do_player_select,
            }, -1
        )

    def _gen_skin(self):
        cells = ""
        for row in range(self.GRID_ROWS):
            for col in range(self.GRID_COLS):
                i  = row * self.GRID_COLS + col
                x  = self.GX + col * (self.CW + self.SX)
                y  = self.GY + row * (self.CH + self.SY)
                cells += """
    <widget name="gb_%d" position="%d,%d" size="%d,%d"
            zPosition="1" backgroundColor="#2a2a2a" borderColor="#555" borderWidth="2" transparent="1"/>
    <widget name="gp_%d" position="%d,%d" size="%d,%d"
            zPosition="2" transparent="1" alphatest="on" scale="1"/>
    <widget name="gl_%d" position="%d,%d" size="%d,%d"
            font="Bold;28" halign="center" valign="center"
            foregroundColor="#ffffff" transparent="1" zPosition="3"/>""" % (
                    i, x, y, self.CW, self.CH,
                    i, x+self.IX_OFF, y+self.IY_OFF, self.IW, self.IH,
                    i, x, y+self.LY_OFF, self.CW, self.LH)

        return """
<screen name="ServersListScreen" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#010103">
    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/config.png" zPosition="-1"/>
    <widget name="title"   position="0,60"   size="1920,45"
            font="Bold;52" halign="center" foregroundColor="#00ff00" transparent="1"/>
    <widget name="pg_info" position="100,115" size="1720,38"
            font="Regular;24" halign="center" foregroundColor="#888" transparent="1"/>
    <widget name="status"  position="100,862" size="1720,40"
            font="Regular;25" halign="center" foregroundColor="#d0de07" transparent="1"/>
    <widget name="btn_delete"  position="400,960"  size="240,55"
            font="Bold;26" halign="center" backgroundColor="#e74c3c" foregroundColor="#fff"/>
    <widget name="btn_add"     position="700,960"  size="240,55"
            font="Bold;26" halign="center" backgroundColor="#2ecc71" foregroundColor="#fff"/>
    <widget name="btn_edit"    position="1000,960" size="240,55"
            font="Bold;26" halign="center" backgroundColor="#f39c12" foregroundColor="#fff"/>
    <widget name="btn_player"  position="1300,960" size="280,55"
            font="Bold;26" halign="center" backgroundColor="#2980b9" foregroundColor="#fff"/>
    %s
</screen>""" % (PLUGIN_PATH, cells)

    # ─── Données ──────────────────────────────────────────────────────────────

    def _load(self):
        try:
            if not os.path.exists(CONFIG_FILE):
                self.servers = []
            else:
                with open(CONFIG_FILE) as f:
                    d = json.load(f)
                self.servers = d.get("servers", []) if isinstance(d, dict) else d

            for s in self.servers:
                s.setdefault("active", False)
                s.setdefault("name",   "Serveur inconnu")
                s.setdefault("type",   "mag")
                if not s.get("host") and s.get("url"):
                    s["host"] = s["url"]
                if s.get("type") == "stalker":
                    s["type"] = "mag"

            # Sélectionner le serveur actif
            ai = next((i for i, s in enumerate(self.servers) if s.get("active")), -1)
            if ai >= 0:
                self.sel  = ai
                self.page = ai // self.PER_PAGE
            else:
                self.sel  = 0
                self.page = 0

            n  = len(self.servers)
            ac = sum(1 for s in self.servers if s.get("active"))
            if n:
                self["status"].setText("%d server(s) loaded  |  %d active" % (n, ac))
            else:
                self["status"].setText("No server found - Press ADD (Green)")

        except Exception as e:
            print("[Servers] Load: %s" % e)
            self.servers = []
            self["status"].setText("Error loading servers")

    def _save(self):
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump({"servers": self.servers,
                           "last_updated": str(datetime.now())}, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print("[Servers] Save: %s" % e)
            return False

    # ─── Affichage ────────────────────────────────────────────────────────────

    def _refresh(self):
        tp = self._tp()
        if tp > 1:
            self["pg_info"].setText("Page %d / %d  (%d server(s))" % (self.page+1, tp, len(self.servers)))
        else:
            self["pg_info"].setText("%d server(s)" % len(self.servers))
        from .server_manager import get_player_label
        self["btn_player"].setText("PLAYER: %s" % get_player_label())
        self._draw()

    def _draw(self):
        ps = self.servers[self.page*self.PER_PAGE:(self.page+1)*self.PER_PAGE]
        g0 = self.page * self.PER_PAGE

        for i in range(self.PER_PAGE):
            bg  = self.grid_bgs[i]
            px  = self.grid_pxs[i]
            lbl = self.grid_lbls[i]

            if i < len(ps):
                s      = ps[i]
                gi     = g0 + i
                active = s.get("active", False)
                sel    = (gi == self.sel)
                stype  = s.get("type", "mag")
                name   = s.get("name", "?")
                if len(name) > 28:
                    name = name[:25] + "..."

                self[bg].hide()

                icon = self.ICON_MAG if stype == "mag" else self.ICON_XTREAM
                try:
                    if os.path.exists(icon) and self[px].instance:
                        self[px].instance.setPixmapFromFile(icon)
                        self[px].instance.setScale(1)
                        self[px].show()
                    else:
                        self[px].hide()
                except:
                    self[px].hide()

                prefix = "CHECK " if active else "CIRCLE "
                self[lbl].setText(name)
                if self[lbl].instance:
                    self[lbl].instance.setForegroundColor(
                        gRGB(255, 255, 100) if sel else
                        gRGB(0,   255,   0) if active else
                        gRGB(200, 200, 200))
                self[lbl].show()

            else:
                if not self.servers and self.page == 0 and i == 0:
                    self[bg].hide()
                    self[px].hide()
                    self[lbl].setText("CLICK ADD")
                    if self[lbl].instance:
                        self[lbl].instance.setForegroundColor(gRGB(100, 100, 255))
                    self[lbl].show()
                else:
                    self[bg].hide()
                    self[px].hide()
                    self[lbl].hide()

    # ─── Actions ──────────────────────────────────────────────────────────────

    def do_add(self):
        self.session.openWithCallback(
            self._on_form_closed,
            ServerFormScreen,
            mode="add"
        )

    def do_edit(self):
        if not self.servers:
            return
        s = self._cur()
        if not s:
            return
        self.session.openWithCallback(
            self._on_form_closed,
            ServerFormScreen,
            mode="edit",
            server_data=s,
            server_index=self.sel
        )

    def _on_form_closed(self, result):
        if result:
            self._load()
            self._refresh()

    def do_player_select(self):
        from .server_manager import PLAYER_ENGINES, PLAYER_ORDER, get_player_engine, set_player_engine
        current = get_player_engine()
        choices = []
        for pid in PLAYER_ORDER:
            label, _ = PLAYER_ENGINES[pid]
            marker = "  [X] " if pid == current else "  [ ] "
            choices.append((marker + label, pid))
        self.session.openWithCallback(
            self._player_selected, ChoiceBox,
            title="Lecteur video (player)",
            list=choices
        )

    def _player_selected(self, choice):
        if not choice:
            return
        from .server_manager import set_player_engine
        pid = choice[1]
        r = set_player_engine(pid)
        if r.get("success"):
            self["btn_player"].setText("PLAYER: %s" % r.get("label", pid))
            self.session.open(MessageBox,
                "Lecteur selectionne:\n%s" % r.get("label", pid),
                MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, "Erreur sauvegarde", MessageBox.TYPE_ERROR, timeout=3)

    def do_connect(self):
        if not self.servers:
            self.session.open(MessageBox, "No server selected", MessageBox.TYPE_ERROR, timeout=3)
            return
        s = self._cur()
        if not s:
            return
        for sv in self.servers:
            sv["active"] = False
        s["active"] = True
        if self._save():
            self._refresh()
            self.session.open(MessageBox,
                "Server activated:\n%s" % s.get("name", ""),
                MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, "Save error", MessageBox.TYPE_ERROR, timeout=3)

    def do_delete(self):
        if not self.servers:
            return
        s = self._cur()
        if not s:
            return
        self.session.openWithCallback(
            lambda r: self._confirm_delete(r, s.get("name", "?")),
            MessageBox,
            "Delete '%s' ?" % s.get("name", "?"),
            MessageBox.TYPE_YESNO
        )

    def _confirm_delete(self, result, name):
        if not result:
            return
        del self.servers[self.sel]
        self.sel  = max(0, min(self.sel, len(self.servers) - 1))
        self.page = self.sel // self.PER_PAGE if self.servers else 0
        if self._save():
            self._refresh()
            n  = len(self.servers)
            ac = sum(1 for s in self.servers if s.get("active"))
            self["status"].setText("%d server(s) loaded  |  %d active" % (n, ac))

    # ─── Navigation ───────────────────────────────────────────────────────────

    def _tp(self):
        return max(1, (len(self.servers) + self.PER_PAGE - 1) // self.PER_PAGE)

    def _cur(self):
        if 0 <= self.sel < len(self.servers):
            return self.servers[self.sel]
        return None

    def keyUp(self):
        new = self.sel - self.GRID_COLS
        if new >= 0:
            self.sel  = new
            self.page = self.sel // self.PER_PAGE
            self._refresh()

    def keyDown(self):
        new = self.sel + self.GRID_COLS
        if new < len(self.servers):
            self.sel  = new
            self.page = self.sel // self.PER_PAGE
            self._refresh()

    def keyLeft(self):
        if self.sel % self.GRID_COLS > 0:
            self.sel -= 1
            self.page = self.sel // self.PER_PAGE
            self._refresh()
        elif self.page > 0:
            self.page -= 1
            last = min(self.page*self.PER_PAGE + self.PER_PAGE - 1, len(self.servers)-1)
            self.sel = last
            self._refresh()

    def keyRight(self):
        if self.sel % self.GRID_COLS < self.GRID_COLS - 1 and self.sel + 1 < len(self.servers):
            self.sel += 1
            self.page = self.sel // self.PER_PAGE
            self._refresh()
        elif self.page + 1 < self._tp():
            self.page += 1
            self.sel   = self.page * self.PER_PAGE
            self._refresh()

    def close(self):
        super().close()
