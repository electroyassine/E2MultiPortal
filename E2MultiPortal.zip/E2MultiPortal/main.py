#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
E2MultiPortal — Menu principal
Ligne 1 : LIVE TV | VOD | SERIES  — texte seul, grand, centré
Ligne 2 : PLAYLIST | CONFIG       — texte seul, centré
Pas d'icones, pas de fond coloré.
"""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Console import Console
from Screens.MessageBox import MessageBox
from enigma import gRGB, eTimer
import os, json, socket, threading
from datetime import datetime

# ── Mise a jour depuis GitHub ────────────────────────────────────────────────
UPDATE_VERSION_URL = "https://raw.githubusercontent.com/electroyassine/E2MultiPortal/refs/heads/main/version.json"
UPDATE_ZIP_URL     = "https://raw.githubusercontent.com/electroyassine/E2MultiPortal/refs/heads/main/E2MultiPortal.zip"
UPDATE_DEST        = "/usr/lib/enigma2/python/Plugins/Extensions"


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80)); ip = s.getsockname()[0]; s.close()
        if ip and not ip.startswith('127.'): return ip
    except: pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith('127.'): return ip
    except: pass
    return None


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/E2MultiPortal"

class E2MultiPortalMain(Screen):

    WEB_PORT = 8070

    # Layout menu : LIVE TV/VOD/SERIES/PLAYLIST/CONFIG positionnes via l'outil
    # positioner.html (image de fond v1.1.8), couleur rouge/jaune.
    # Ligne 1 — LIVE TV (38,298,268x132) | VOD (286,294,270x136) |
    #           SERIES (534,294,284x136) : font Bold;33
    # Ligne 2 — PLAYLIST (20,726,480x54) | CONFIG (310,726,480x54) : font Bold;33

    skin = """
<screen name="E2MultiPortalMain" position="center,center" size="1920,1080"
        flags="wfNoBorder" backgroundColor="#08081a">

    <ePixmap position="0,0" size="1920,1080"
             pixmap="%s/skins/menu.png" zPosition="-1"/>

    <!-- Date / statut serveur -->
    <widget name="date_display" position="1570,55" size="330,40"
            font="Bold;24" halign="right" valign="center"
            foregroundColor="#f1f90b" transparent="1" zPosition="2"/>
    <widget name="server_status" position="20,55" size="1500,40"
            font="Bold;24" halign="left" valign="center"
            foregroundColor="#f1f90b" transparent="1" zPosition="2"/>

    <!-- ═══ LIGNE 1 : LIVE TV | VOD | SERIES (centrees sur l'image menu) ═══ -->
    <widget name="lbl_live"   position="38,298" size="268,132"
            font="Bold;33" halign="center" valign="center"
            foregroundColor="#ff3333" transparent="1" zPosition="4"/>

    <widget name="lbl_vod"    position="286,294" size="270,136"
            font="Bold;33" halign="center" valign="center"
            foregroundColor="#ff3333" transparent="1" zPosition="4"/>

    <widget name="lbl_series" position="534,294" size="284,136"
            font="Bold;33" halign="center" valign="center"
            foregroundColor="#ff3333" transparent="1" zPosition="4"/>

    <!-- ═══ LIGNE 2 : PLAYLIST | CONFIG (centrees sur l'image menu) ═══ -->
    <widget name="lbl_playlist" position="20,726" size="480,54"
            font="Bold;33" halign="center" valign="center"
            foregroundColor="#ff3333" transparent="1" zPosition="4"/>

    <widget name="lbl_config"   position="310,726" size="480,54"
            font="Bold;33" halign="center" valign="center"
            foregroundColor="#ff3333" transparent="1" zPosition="4"/>


    <!-- EXIT + MISE A JOUR (a gauche du menu) -->
    <widget name="key_red" position="40,970" size="250,52"
            font="Bold;30" halign="center" valign="center"
            backgroundColor="#922020" foregroundColor="#ffffff" zPosition="3"/>

    <widget name="key_yellow" position="310,970" size="250,52"
            font="Bold;30" halign="center" valign="center"
            backgroundColor="#a89000" foregroundColor="#000000" zPosition="3"/>

    <!-- IP / Web (bas a droite, a cote de EXIT) -->
    <widget name="ip_display"  position="1020,978" size="860,34"
            font="Regular;26" halign="right" valign="center"
            foregroundColor="#00cc88" transparent="1" zPosition="2"/>

</screen>""" % PLUGIN_PATH

    def __init__(self, session):
        Screen.__init__(self, session)
        from . import poster_manager as PM
        os.makedirs(PM.DIR_PERM, exist_ok=True)

        self["date_display"]  = Label("")
        self["ip_display"]    = Label("")
        self["server_status"] = Label("")
        self["key_red"]       = Label("  EXIT")
        self["key_yellow"]    = Label(" MISE A JOUR")

        self["lbl_live"]      = Label("LIVE TV")
        self["lbl_vod"]       = Label("VOD")
        self["lbl_series"]    = Label("SERIES")
        self["lbl_playlist"]  = Label("PLAYLIST")
        self["lbl_config"]    = Label("CONFIG")

        self.menu_items = [
            {"label":"lbl_live",     "action":self.open_live_tv,  "requires_server":True},
            {"label":"lbl_vod",      "action":self.open_vod,      "requires_server":False},
            {"label":"lbl_series",   "action":self.open_series,   "requires_server":False},
            {"label":"lbl_playlist", "action":self.open_playlist, "requires_server":False},
            {"label":"lbl_config",   "action":self.open_servers,  "requires_server":False},
        ]
        self.current_index = 0
        self.active_server = None

        self.update_ip_display()
        self.update_date_display()
        self.check_server_status()

        self._date_timer = eTimer()
        self._date_timer.callback.append(self.update_date_display)
        self._date_timer.start(60000, False)

        self["actions"] = ActionMap(
            ["DirectionActions","OkCancelActions","ColorActions"],
            {
                "up":     self.keyUp,
                "down":   self.keyDown,
                "left":   self.keyLeft,
                "right":  self.keyRight,
                "ok":     self.keyOk,
                "red":    self.exit,
                "yellow": self.check_update,
                "cancel": self.exit,
            }, -1
        )
        self.onLayoutFinish.append(self._init_focus)

    # ── Utilitaires ────────────────────────────────────────────────────────────
    def _read_version(self):
        try:
            with open(PLUGIN_PATH+"/version.json") as f:
                return json.load(f).get("version","1.0.0")
        except: return "1.0.0"

    @staticmethod
    def _version_tuple(v):
        parts = []
        for p in str(v).strip().split("."):
            try:
                parts.append(int(p))
            except ValueError:
                parts.append(0)
        return tuple(parts)

    # ── Mise a jour ──────────────────────────────────────────────────────────
    def check_update(self):
        self["server_status"].setText("Verification de mise a jour...")
        threading.Thread(target=self._check_update_thread, daemon=True).start()

    def _check_update_thread(self):
        try:
            import urllib.request
            req = urllib.request.Request(
                UPDATE_VERSION_URL, headers={"User-Agent": "E2MultiPortal"})
            with urllib.request.urlopen(req, timeout=10) as r:
                remote = json.loads(r.read().decode("utf-8"))
            remote_v = str(remote.get("version", ""))
            local_v  = self._read_version()

            if remote_v and self._version_tuple(remote_v) > self._version_tuple(local_v):
                self.session.openWithCallback(
                    self._update_confirmed, MessageBox,
                    "Nouvelle version disponible : v%s\n"
                    "Version actuelle : v%s\n\n"
                    "Telecharger et installer la mise a jour maintenant ?" % (remote_v, local_v),
                    MessageBox.TYPE_YESNO)
            else:
                self.session.open(
                    MessageBox,
                    "Vous avez deja la derniere version (v%s)." % local_v,
                    MessageBox.TYPE_INFO, timeout=4)
            self.check_server_status()
        except Exception as e:
            self.session.open(
                MessageBox,
                "Erreur lors de la verification de mise a jour:\n%s" % str(e)[:120],
                MessageBox.TYPE_ERROR, timeout=5)
            self.check_server_status()

    def _update_confirmed(self, yes):
        if not yes:
            return
        self["server_status"].setText("Telechargement de la mise a jour...")
        cmd = (
            'wget -q "--no-check-certificate" "%s" -O /tmp/E2MultiPortal.zip '
            '&& rm -rf "%s/E2MultiPortal" '
            '&& unzip -o /tmp/E2MultiPortal.zip -d "%s" >/dev/null '
            '&& rm -f /tmp/E2MultiPortal.zip'
        ) % (UPDATE_ZIP_URL, UPDATE_DEST, UPDATE_DEST)
        self._update_console = Console()
        self._update_console.ePopen(cmd, self._update_done)

    def _update_done(self, result, retval, extra_args):
        if retval != 0:
            self.session.open(
                MessageBox,
                "Erreur pendant la mise a jour (code %d).\n%s" % (retval, (result or "")[:200]),
                MessageBox.TYPE_ERROR, timeout=6)
            self.check_server_status()
            return
        self.session.openWithCallback(
            self._restart_confirmed, MessageBox,
            "Mise a jour installee avec succes !\n\n"
            "Redemarrer l'interface Enigma2 maintenant pour appliquer la mise a jour ?",
            MessageBox.TYPE_YESNO)

    def _restart_confirmed(self, yes):
        if not yes:
            self["server_status"].setText(
                "Mise a jour installee — redemarrez Enigma2 manuellement pour l'appliquer.")
            return
        self._restart_console = Console()
        self._restart_console.ePopen("init 4 && sleep 2 && init 3")

    def update_date_display(self):
        self["date_display"].setText(datetime.now().strftime("%d/%m/%Y  %H:%M"))

    def update_ip_display(self):
        ip = get_local_ip()
        if ip:
            self["ip_display"].setText("IP : %s     Web : http://%s:%d" % (ip,ip,self.WEB_PORT))
        else:
            self["ip_display"].setText("Non connecte au reseau")

    def check_server_status(self):
        cf = "/etc/enigma2/E2MultiPortal/servers.json"
        try:
            if not os.path.exists(cf):
                self.active_server=None
                self["server_status"].setText("Aucun serveur — ajoutez via CONFIG ou l'interface web")
                return
            with open(cf) as f:
                data = json.load(f)
            for s in data.get("servers",[]):
                if s.get("active"):
                    self.active_server=s
                    txt = "Serveur actif : [%s]  %s" % (s.get("type","").upper(), s.get("name",""))
                    exp = s.get("expiration", "")
                    if exp:
                        txt += "   |   Expire : %s" % exp
                    self["server_status"].setText(txt)
                    return
            self.active_server=None
            self["server_status"].setText("Aucun serveur actif — ouvrez PLAYLIST ou CONFIG")
        except:
            self.active_server=None
            self["server_status"].setText("Erreur configuration")

    # ── Focus ──────────────────────────────────────────────────────────────────
    def _init_focus(self):
        self._update_colors()

    def _update_colors(self):
        for i, item in enumerate(self.menu_items):
            w = self[item["label"]]
            if w.instance:
                if i == self.current_index:
                    # Jaune vif, transparent (pas de fond)
                    w.instance.setForegroundColor(gRGB(0xf1, 0xf9, 0x0b))
                    w.instance.setTransparent(1)
                else:
                    # Rouge, transparent (couleur de base des libelles)
                    w.instance.setForegroundColor(gRGB(0xff, 0x33, 0x33))
                    w.instance.setTransparent(1)


    # ── Navigation ────────────────────────────────────────────────────────────
    def keyRight(self):
        if self.current_index in (0,1,2):
            self.current_index = (self.current_index+1)%3
        else:
            self.current_index = 3 if self.current_index==4 else 4
        self._update_colors()

    def keyLeft(self):
        if self.current_index in (0,1,2):
            self.current_index = (self.current_index-1)%3
        else:
            self.current_index = 4 if self.current_index==3 else 3
        self._update_colors()

    def keyDown(self):
        if self.current_index in (0,1,2):
            self.current_index = 3 if self.current_index<=1 else 4
        else:
            self.current_index = 0 if self.current_index==3 else 2
        self._update_colors()

    def keyUp(self):
        if self.current_index in (3,4):
            self.current_index = 0 if self.current_index==3 else 2
        else:
            self.current_index = 3 if self.current_index<=1 else 4
        self._update_colors()

    def keyOk(self):
        item = self.menu_items[self.current_index]
        if item.get("requires_server") and not self.active_server:
            self.session.open(MessageBox,
                "Aucun serveur actif !\nOuvrez CONFIG pour configurer un serveur.",
                MessageBox.TYPE_ERROR, timeout=4)
            return
        item["action"]()

    # ── Ouverture ──────────────────────────────────────────────────────────────
    def open_live_tv(self):
        try:
            from .live import LiveScreen
            self.session.open(LiveScreen)
        except Exception as e: self._err("Live TV: %s"%e)

    def open_vod(self):
        try:
            from .vod import VodScreen
            self.session.open(VodScreen)
        except Exception as e: self._err("VOD: %s"%e)

    def open_series(self):
        try:
            from .series import SeriesScreen
            self.session.open(SeriesScreen)
        except Exception as e: self._err("Series: %s"%e)

    def open_playlist(self):
        try:
            from .playlist import PlaylistScreen
            self.session.openWithCallback(self._on_closed, PlaylistScreen)
        except Exception as e: self._err("Playlist: %s"%e)

    def open_servers(self):
        try:
            from .servers_list import ServersListScreen
            self.session.openWithCallback(self._on_closed, ServersListScreen)
        except Exception as e: self._err("Servers: %s"%e)

    def _on_closed(self, result=None):
        self.check_server_status()

    def _err(self, msg):
        print("[E2MultiPortal] %s"%msg)
        self.session.open(MessageBox, msg[:100], MessageBox.TYPE_ERROR, timeout=4)

    def exit(self):
        try: self._date_timer.stop()
        except: pass
        super().close()
