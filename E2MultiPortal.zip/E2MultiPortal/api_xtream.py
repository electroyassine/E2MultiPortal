#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2MultiPortal - API Xtream Codes
Gestion et test des serveurs Xtream Codes
"""

import json
import ssl
import urllib.request
import urllib.parse
from urllib.parse import urlparse


class XtreamAPI:
    """Gestionnaire API Xtream Codes"""

    def __init__(self, host, username, password, port=80):
        self.host = host.rstrip('/')
        self.username = username
        self.password = password
        self.port = int(port)

    def _build_url(self, action=None, stream_id=None, extra=None):
        """Construit une URL Xtream"""
        base = f"{self.host}/player_api.php?username={self.username}&password={self.password}"
        if action:
            base += f"&action={action}"
        if stream_id:
            base += f"&stream_id={stream_id}"
        if extra:
            base += f"&{extra}"
        return base

    def _fetch(self, url, timeout=15):
        """Effectue une requête HTTP"""
        try:
            context = ssl._create_unverified_context()
            req = urllib.request.Request(
                url,
                headers={'User-Agent': 'E2MultiPortal/1.0'}
            )
            with urllib.request.urlopen(req, context=context, timeout=timeout) as resp:
                data = resp.read().decode('utf-8', errors='ignore')
                return json.loads(data)
        except Exception as e:
            return None

    def test_connection(self):
        """Teste la connexion au serveur Xtream"""
        url = self._build_url()
        try:
            context = ssl._create_unverified_context()
            req = urllib.request.Request(url, headers={'User-Agent': 'E2MultiPortal/1.0'})
            with urllib.request.urlopen(req, context=context, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8', errors='ignore'))
                if data and "user_info" in data:
                    ui = data["user_info"]
                    si = data.get("server_info", {})
                    return {
                        "success": True,
                        "status": ui.get("status", "active"),
                        "username": ui.get("username", self.username),
                        "active_cons": ui.get("active_cons", 0),
                        "max_connections": ui.get("max_connections", 1),
                        "expiration": ui.get("exp_date", "N/A"),
                        "timezone": si.get("timezone", ""),
                        "server_protocol": si.get("server_protocol", "http"),
                        "message": "Connexion réussie"
                    }
                else:
                    return {"success": False, "message": "Réponse invalide du serveur"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    def get_live_categories(self):
        """Récupère les catégories Live"""
        url = self._build_url(action="get_live_categories")
        return self._fetch(url) or []

    def get_vod_categories(self):
        """Récupère les catégories VOD"""
        url = self._build_url(action="get_vod_categories")
        return self._fetch(url) or []

    def get_series_categories(self):
        """Récupère les catégories Séries"""
        url = self._build_url(action="get_series_categories")
        return self._fetch(url) or []

    def get_live_streams(self, category_id=None):
        """Récupère les chaînes Live"""
        extra = f"category_id={category_id}" if category_id else None
        url = self._build_url(action="get_live_streams", extra=extra)
        return self._fetch(url) or []

    def get_vod_streams(self, category_id=None):
        """Récupère les films VOD"""
        extra = f"category_id={category_id}" if category_id else None
        url = self._build_url(action="get_vod_streams", extra=extra)
        return self._fetch(url) or []

    def get_series(self, category_id=None):
        """Récupère les séries"""
        extra = f"category_id={category_id}" if category_id else None
        url = self._build_url(action="get_series", extra=extra)
        return self._fetch(url) or []

    def get_stream_url(self, stream_id, stream_type="live", ext="ts"):
        """Construit l'URL de streaming"""
        return f"{self.host}/{stream_type}/{self.username}/{self.password}/{stream_id}.{ext}"

    @staticmethod
    def test_server_from_data(host, username, password, port=80):
        """Test statique depuis les données brutes"""
        api = XtreamAPI(host, username, password, port)
        return api.test_connection()
